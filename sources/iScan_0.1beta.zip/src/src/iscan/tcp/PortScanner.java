/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.tcp;

import iscan.Constants;
import iscan.gui.MasterFrame;
import java.io.File;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.*;

public class PortScanner {
    private MasterFrame frame;
    private Object[]    services;
    private boolean     stopped;
    
    public PortScanner( MasterFrame frame ) throws Exception {
        this.frame    = frame;
        this.loadServices("data/tcpservices.xml");
    }
    
    private void loadServices( String filename ) throws Exception {
        DocumentBuilderFactory docfactory = DocumentBuilderFactory.newInstance();
        docfactory.setCoalescing(true);
        DocumentBuilder        docbuilder = docfactory.newDocumentBuilder();
        Document               document   = docbuilder.parse(new File(filename));
        Vector<Service>        vect       = new Vector<Service>();
        
        int i, j;
        
        document.getDocumentElement().normalize();
        
        NodeList items = document.getElementsByTagName("service");
        
        for( i = 0; i < items.getLength(); i++ ){
            Element root = (Element)items.item(i);
            Service svc  = new Service();
            
            if( root.getElementsByTagName("port") != null ){
                if( root.getElementsByTagName("port").item(0) != null ){
                    String value = ((Element)root.getElementsByTagName("port").item(0)).getChildNodes().item(0).getNodeValue();
                    Integer ival = Integer.parseInt(value);
                    svc.port = ival.intValue();
                }
            }
            if( root.getElementsByTagName("name") != null ){
                if( root.getElementsByTagName("name").item(0) != null ){
                    svc.name = ((Element)root.getElementsByTagName("name").item(0)).getChildNodes().item(0).getNodeValue();
                }
            }
            if( root.getElementsByTagName("description") != null ){
                if( root.getElementsByTagName("description").item(0) != null ){
                    if( ((Element)root.getElementsByTagName("description").item(0)).getChildNodes().item(0) != null ){
                        svc.description = ((Element)root.getElementsByTagName("description").item(0)).getChildNodes().item(0).getNodeValue();
                    }
                }
            }
            
            vect.add(svc);
        }
        
        this.services = vect.toArray();
    }
    
    public synchronized void stop(){
        this.stopped  = true;
        frame.pscanbutton().setEnabled(false);
    }
    
    public synchronized boolean isRunning(){
        return (this.stopped == false);
    }
    
    public void start( String host ){
        this.stopped  = false;
        final String asynchost = host;
        Thread thread = new Thread( new Runnable() {
            public void run() {                
                for( int i = 0; i < services.length && isRunning(); i += Constants.max_running_threads ){ 
                    Thread thread = null;
                    for( int j = i; j < i + Constants.max_running_threads && isRunning(); j++ ){
                        final Service s = (Service)services[j];
                        thread = new Thread( new Runnable() {
                            public void run() {
                                if( s.isOpen(asynchost) ){
                                    frame.addService(s);
                                }
                            }
                        });
                        
                        thread.start();
                    }
                    
                    frame.pscanbar().setValue(i + 1);
                    frame.pscanbar().repaint();
                    
                    while( thread.isAlive() && isRunning() ){
                        try{
                            Thread.sleep(1000);
                        }
                        catch(Exception e){
                            e.printStackTrace();
                            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                frame.pscanbutton().setEnabled(false);
            }
        });
        thread.start();
    }
}
