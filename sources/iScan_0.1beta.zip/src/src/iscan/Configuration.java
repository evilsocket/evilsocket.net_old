/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */


package iscan;

import iscan.utils.StringManager;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Vector;

public class Configuration {
    private static volatile Configuration INSTANCE = null;
    private File   file;
    
    public String  useragent    = "";
    public String  referer      = "";
    public boolean crawdelayenabled = false;
    public int     crawldelay   = 0;
    public boolean proxyenabled = false;
    public String  proxyserver  = "";
    public int     proxyport    = 0;
    public int     maxdirdepth  = 10;
    public Vector<String> allowedext = new Vector<String>();
    
    
    public HashMap map;
    
    public Configuration( String filename ) throws Exception {
        this.file             = new File(filename);
        BufferedReader reader = new BufferedReader( new FileReader(this.file) );
        String line           = null;
        this.map              = new HashMap();
        
        while( (line = reader.readLine()) != null ){
            // skip comments
            if( line.startsWith("#") == false ){
                if( line.startsWith("UserAgent") ){
                    this.useragent = StringManager.getAfter( line, "UserAgent" ).trim();
                }
                else if( line.startsWith("Referer") ){
                    this.referer = StringManager.getAfter( line, "Referer" ).trim();
                }
                else if( line.startsWith("CrawlDelay ") ){
                    Integer i = Integer.parseInt( StringManager.getAfter( line, "CrawlDelay" ).trim() );
                    this.crawldelay = i.intValue();
                }
                else if( line.startsWith("MaxDirectoryDepth ") ){
                    Integer i = Integer.parseInt( StringManager.getAfter( line, "MaxDirectoryDepth" ).trim() );
                    this.maxdirdepth = i.intValue();
                }
                else if( line.startsWith("CrawlDelayEnabled") ){
                    String sbool = StringManager.getAfter( line, "CrawlDelayEnabled" ).trim();
                    if( sbool.equalsIgnoreCase("false") ){
                        this.crawdelayenabled = false;
                    }
                    else{
                        this.crawdelayenabled = true;
                    }
                }
                else if( line.startsWith("ProxyEnabled") ){
                    String sbool = StringManager.getAfter( line, "ProxyEnabled" ).trim();
                    if( sbool.equalsIgnoreCase("false") ){
                        this.proxyenabled = false;
                    }
                    else{
                        this.proxyenabled = true;
                    }
                }
                else if( line.startsWith("ProxyServer") ){
                    this.proxyserver = StringManager.getAfter( line, "ProxyServer" ).trim();
                }
                else if( line.startsWith("ProxyPort") ){
                    Integer i = Integer.parseInt(StringManager.getAfter( line, "ProxyPort" ).trim() );
                    this.proxyport = i.intValue();
                }
                else if( line.startsWith("AllowedExtensions") ){
                    String[] ext = StringManager.getAfter( line, "AllowedExtensions" ).trim().split(",");
                    for( String e : ext ){
                        this.allowedext.add(e.trim());
                    }
                }
                
                if( line.contains(" ") ){
                    String key = "", val = "";
                    key = StringManager.getBefore( line, " " );
                    val = StringManager.getAfter( line, " " );
                    this.map.put(key, val);
                }
            }
        }
        
        reader.close();
        
        Configuration.INSTANCE = this;
    }
    
    public void update( HashMap map ) throws Exception {
        BufferedWriter writer = new BufferedWriter( new FileWriter(this.file) );
        Object[] keys = map.keySet().toArray();
        int ki;
        for( ki = 0; ki < keys.length; ki++ ){
            writer.write( keys[ki] + " " + map.get(keys[ki]) + "\r\n" );
        }
        writer.close();
        this.map = map;
        
        BufferedReader reader = new BufferedReader( new FileReader(this.file) );
        String line           = null;
                
        while( (line = reader.readLine()) != null ){
            // skip comments
            if( line.startsWith("#") == false ){
                if( line.startsWith("UserAgent") ){
                    this.useragent = StringManager.getAfter( line, "UserAgent" ).trim();
                }
                else if( line.startsWith("Referer") ){
                    this.referer = StringManager.getAfter( line, "Referer" ).trim();
                }
                else if( line.startsWith("CrawlDelay ") ){
                    Integer i = Integer.parseInt( StringManager.getAfter( line, "CrawlDelay" ).trim() );
                    this.crawldelay = i.intValue();
                }
                else if( line.startsWith("MaxDirectoryDepth ") ){
                    Integer i = Integer.parseInt( StringManager.getAfter( line, "MaxDirectoryDepth" ).trim() );
                    this.maxdirdepth = i.intValue();
                }
                else if( line.startsWith("CrawlDelayEnabled") ){
                    String sbool = StringManager.getAfter( line, "CrawlDelayEnabled" ).trim();
                    if( sbool.equalsIgnoreCase("false") ){
                        this.crawdelayenabled = false;
                    }
                    else{
                        this.crawdelayenabled = true;
                    }
                }
                else if( line.startsWith("ProxyEnabled") ){
                    String sbool = StringManager.getAfter( line, "ProxyEnabled" ).trim();
                    if( sbool.equalsIgnoreCase("false") ){
                        this.proxyenabled = false;
                    }
                    else{
                        this.proxyenabled = true;
                    }
                }
                else if( line.startsWith("ProxyServer") ){
                    this.proxyserver = StringManager.getAfter( line, "ProxyServer" ).trim();
                }
                else if( line.startsWith("ProxyPort") ){
                    Integer i = Integer.parseInt(StringManager.getAfter( line, "ProxyPort" ).trim() );
                    this.proxyport = i.intValue();
                }
                else if( line.startsWith("AllowedExtensions") ){
                    this.allowedext.clear();
                    String[] ext = StringManager.getAfter( line, "AllowedExtensions" ).trim().split(",");
                    for( String e : ext ){
                        this.allowedext.add(e);
                    }
                }
            }
        }
        
        reader.close();
        Configuration.setInstance(this);
    }
    
    public static Configuration getInstance(){
        return Configuration.INSTANCE;
    }
    
    public static void setInstance( Configuration config ){
        Configuration.INSTANCE = config;
    }
}
