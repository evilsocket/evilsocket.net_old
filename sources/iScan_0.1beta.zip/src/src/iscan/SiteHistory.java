/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Vector;

public class SiteHistory {
    private File file;
    private BufferedReader reader;
    private BufferedWriter writer;
    
    public SiteHistory( String filename ) throws Exception {
        this.file = new File(filename);
        if( this.file.exists() == false ){
            this.file.createNewFile();
        }
        this.writer = new BufferedWriter( new FileWriter(this.file,true) );
    }
    
    public Vector load() throws Exception{
        Vector lines = new Vector();
        String line  = null;
        this.reader  = new BufferedReader( new FileReader(this.file) );
        
        while( (line = this.reader.readLine()) != null ){
            if( lines.contains(line) == false ){
                lines.add(line);
            }
        }
                
        return lines;
    }
    
    public void add( String line ) throws Exception {
        this.writer.append(line + "\r\n");
        this.writer.flush();
    }
}
