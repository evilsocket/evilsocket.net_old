/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan;

import iscan.gui.components.AlertNodeObject;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Vector;

public class Report {
    private Template header         = null;
    private Vector<Template> alerts = null;
    private Template footer         = null;
    
    public Report() throws Exception {
        this.header = new Template( "data/templates/reportheader.htm" );
        this.alerts = new Vector<Template>();
        this.footer = new Template( "data/templates/reportfooter.htm" );
    }
    
    public void setHeader( String key, String value ){
        this.header.set(key, value);
    }
    
    public void addAlert( AlertNodeObject alert ) throws Exception {
        Template tpl = new Template("data/templates/reportalertbody.htm");
        
        tpl.set( "@I",             String.valueOf(this.alerts.size()) );
        tpl.set( "@TARGET",        alert.toString() );
        tpl.set( "@METHOD",        alert.method() );
        tpl.set( "@NAME",          alert.vulnerability.name  );
        tpl.set( "@FULLURL",       alert.fullurl() );
        tpl.set( "@SEVERITYCOLOR", alert.color() );
        tpl.set( "@SEVERITY",      alert.vulnerability.severity );
        tpl.set( "@DESCRIPTION",   alert.vulnerability.description );
        tpl.set( "@RESPONSE",      alert.response );
        
        this.alerts.add(tpl);
    }
    
    public String html(){
        String html = this.header.html();
        for( int i = 0; i < this.alerts.size(); i++ ){
            html += this.alerts.get(i).html();
        }
        html += this.footer.html();
        
        return html;
    }
    
    public void save( String filename ) throws Exception {
        BufferedWriter w = new BufferedWriter(new FileWriter( new File(filename)));
        w.write(this.html());
        w.close();
    }
}
