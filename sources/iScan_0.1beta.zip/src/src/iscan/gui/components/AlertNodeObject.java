/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.gui.components;

import iscan.http.HttpInfo;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.scanner.db.Vulnerability;


public class AlertNodeObject{
    public GetRequest     get  = null;
    public PostRequest    post = null;
    public String        response = "";
    public Vulnerability vulnerability = null;
    public int           payload_idx = 0;
    public int           match_idx   = 0;
    
    public String method(){
        if( this.get != null ){
            return "GET";
        }
        else if( this.post != null ){
            return "POST";
        }
        else{
            return "HEAD";
        }
    }
    
    public String color(){
        if( this.vulnerability.severity.equalsIgnoreCase("very low") ){
            return "blue";
        }
        else if( this.vulnerability.severity.equalsIgnoreCase("low") ){
            return "green";
        }
        else if( this.vulnerability.severity.equalsIgnoreCase("medium") ){
            return "yellow";
        }
        else if( this.vulnerability.severity.equalsIgnoreCase("high") ){
            return "red";
        }
        else{
            return "";
        }
    }
    
    public String fullurl(){
        if( this.get != null ){
            return this.get.longurl();
        }
        else if( this.post != null ){
            return this.post.longurl();
        }
        else{
            return HttpInfo.getInstance().hostname;
        }
    }
    
    public String toString(){
        if( this.get != null ){
            String page = this.get.page();
            if( page.contains("://") ){
                page = page.substring( page.indexOf("://") + 3 );
            }
            page = page.substring(page.indexOf("/"));
            
            return page;
        }
        else if( this.post != null ){
            String page = this.post.action();
            if( page.contains("://") ){
                page = page.substring( page.indexOf("://") + 3 );
            }
            page = page.substring(page.indexOf("/"));
            
            return page;
        }
        else{
            return HttpInfo.getInstance().hostname;
        }
    }
}
