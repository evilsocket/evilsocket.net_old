/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.gui.components;

import iscan.http.requests.GetRequest;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.JTree;
import javax.swing.text.Position;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;


public class WebTree extends JTree {
    private Vector<String> page_cache;
    
    public WebTree(){
        super();
        this.page_cache = new Vector<String>();
        DefaultMutableTreeNode parentnode = new DefaultMutableTreeNode("/");
        ((DefaultTreeModel)this.getModel()).setRoot(parentnode);
        this.setShowsRootHandles(true);
    }
    
    public void reset(){
        DefaultMutableTreeNode parentnode = new DefaultMutableTreeNode("/");
        ((DefaultTreeModel)this.getModel()).setRoot(parentnode);
        this.page_cache.clear();
    }
    
    public synchronized void addUrl( GetRequest url ){
        if( this.page_cache.contains(url.page()) == false ){
            this.page_cache.add(url.page());
            Object[] dirs  = url.dirs().toArray();
            rebuildTree( dirs );
            this.repaint();
        }
    }
    
    private Object[] subTree( Object[] tree, int size ){
        Object[] sub = new Object[size];
        System.arraycopy( tree, 0, sub, 0, size );
        return sub;
    }
    
    private synchronized void rebuildTree( Object[] dirs ){
        DefaultTreeModel model = (DefaultTreeModel)this.getModel();
        DefaultMutableTreeNode newnode, parentnode = (DefaultMutableTreeNode)model.getRoot();
        TreePath   path;
        int i;
        
        for( i = 1; i < dirs.length; i++ ){
            Object[] subtree = subTree(dirs,i + 1);
            
            if( (path = findByName(subtree)) == null ){
                newnode = new DefaultMutableTreeNode(dirs[i]);
                model.insertNodeInto( newnode, parentnode, parentnode.getChildCount() );
                parentnode = newnode;
                path = this.getNextMatch( (String)dirs[i], 0, Position.Bias.Forward );
            }
            else{
                parentnode = (DefaultMutableTreeNode)path.getLastPathComponent();
            }

            this.expandAll(true);
        }
    }
    
    public void expandAll(boolean expand) {
        TreeNode root = (TreeNode)this.getModel().getRoot();
    
        // Traverse tree from root
        expandAll( new TreePath(root), expand);
    }
    private void expandAll( TreePath parent, boolean expand) {
        // Traverse children
        TreeNode node = (TreeNode)parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e=node.children(); e.hasMoreElements(); ) {
                TreeNode n = (TreeNode)e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll( path, expand);
            }
        }
    
        // Expansion or collapse must be done bottom-up
        if (expand) {
            this.expandPath(parent);
        } else {
            this.collapsePath(parent);
        }
    }
    
    public TreePath findByName(Object[] names) {
        TreeNode root = (TreeNode)this.getModel().getRoot();
        return find2( new TreePath(root), names, 0, true);
    }
    
    private TreePath find2( TreePath parent, Object[] nodes, int depth, boolean byName) {
        TreeNode node = (TreeNode)parent.getLastPathComponent();
        Object o = node;
    
        // If by name, convert node to a string
        if (byName) {
            o = o.toString();
        }
    
        // If equal, go down the branch
        if (o.equals(nodes[depth])) {
            // If at end, return match
            if (depth == nodes.length-1) {
                return parent;
            }
    
            // Traverse children
            if (node.getChildCount() >= 0) {
                for (Enumeration e=node.children(); e.hasMoreElements(); ) {
                    TreeNode n = (TreeNode)e.nextElement();
                    TreePath path = parent.pathByAddingChild(n);
                    TreePath result = find2( path, nodes, depth+1, byName);
                    // Found a match
                    if (result != null) {
                        return result;
                    }
                }
            }
        }
    
        // No match at this branch
        return null;
    }
}
