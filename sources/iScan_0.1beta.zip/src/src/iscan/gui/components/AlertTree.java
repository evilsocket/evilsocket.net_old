/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.gui.components;

import iscan.http.HttpInfo;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.scanner.db.Vulnerability;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.JTree;
import javax.swing.text.Position;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class AlertTree extends JTree {
    private Vector<String> cache;
    private Vector<AlertNodeObject> alerts;
    
    public AlertTree() {
        super();
        DefaultMutableTreeNode parentnode = new DefaultMutableTreeNode("Alerts");
        ((DefaultTreeModel)this.getModel()).setRoot(parentnode);
        this.setShowsRootHandles(true);
        this.cache  = new Vector<String>();
        this.alerts = new Vector<AlertNodeObject>();
    }
    
    public void reset(){
        DefaultMutableTreeNode parentnode = new DefaultMutableTreeNode("Alerts");
        ((DefaultTreeModel)this.getModel()).setRoot(parentnode);
        this.cache.clear();
        this.alerts.clear();
    }
    
    public Vector<AlertNodeObject> alerts(){
        return this.alerts;
    }
    
    public AlertNodeObject findAlert( int idx, String name ){
        int i, ii = 0;
        for( i = 0; i < this.alerts.size(); i++ ){
            AlertNodeObject alert = this.alerts.get(i);
            if( alert.vulnerability.name.equals(name) ){
                if( ii == idx ){
                    return alert;
                }
                else{
                    ii++;
                }
            }
        }
        return null;
    }
    
    public String severityByName( String name ){
        int i;
        for( i = 0; i < this.alerts.size(); i++ ){
            AlertNodeObject alert = this.alerts.get(i);
            if( alert.vulnerability.name.equals(name) ){
                return alert.vulnerability.severity;
            }
        }
        return null;
    }
    
    public void clear(){
        ((DefaultTreeModel)this.getModel()).setRoot(null);
        this.alerts.clear();
    }
    
    public synchronized void addHeaderAlert( String response, Vulnerability v, int payload, int match ){
        if( this.cache.contains(v) == false ){
            this.cache.add(v.name);
            
            DefaultTreeModel       model  = (DefaultTreeModel)this.getModel();
            TreePath               path   = null;
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getRoot(),
                                   node   = null;
            
            /* search vulnerability name */
            path = this.getNextMatch( (String)v.name, 0, Position.Bias.Forward );
            if( path == null ){
                node = new DefaultMutableTreeNode(v.name);
                model.insertNodeInto( node, parent, 0 );
                parent = node;
            }
            else{
                parent = (DefaultMutableTreeNode)path.getLastPathComponent();
            }
            
            /* add url */
            model.insertNodeInto( new DefaultMutableTreeNode(HttpInfo.getInstance().hostname), parent, 0 );
            
            AlertNodeObject alert = new AlertNodeObject();
            alert.vulnerability = v;
            alert.payload_idx   = payload;
            alert.match_idx     = match;
            alert.response      = response;
            this.alerts.add(alert);
            
            this.expandAll( true );
            this.repaint();
        }
    }
    
    public synchronized void addGetAlert( GetRequest get, String response, Vulnerability v, int payload, int match ){
        if( this.cache.contains(get.longurl()) == false || get.elements() == 0 ){
            this.cache.add(get.longurl());
            
            DefaultTreeModel       model  = (DefaultTreeModel)this.getModel();
            TreePath               path   = null;
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getRoot(),
                                   node   = null;
            
            /* search vulnerability name */
            path = this.getNextMatch( (String)v.name, 0, Position.Bias.Forward );
            if( path == null ){
                node = new DefaultMutableTreeNode(v.name);
                model.insertNodeInto( node, parent, 0 );
                parent = node;
            }
            else{
                parent = (DefaultMutableTreeNode)path.getLastPathComponent();
            }
            
            /* add url */
            model.insertNodeInto( new DefaultMutableTreeNode(get.page()), parent, 0 );
            
            AlertNodeObject alert = new AlertNodeObject();
            alert.get           = get;
            alert.vulnerability = v;
            alert.payload_idx   = payload;
            alert.match_idx     = match;
            alert.response      = response;
            this.alerts.add(alert);
            
            this.expandAll( true );
            this.repaint();
        }
    }
    
    public synchronized void addPostAlert( PostRequest post, String response, Vulnerability v, int payload, int match ){
        if( this.cache.contains(post.longurl()) == false ){
            this.cache.add(post.longurl());
            
            DefaultTreeModel       model  = (DefaultTreeModel)this.getModel();
            TreePath               path   = null;
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getRoot(),
                                   node   = null;
            
            /* search vulnerability name */
            path = this.getNextMatch( (String)v.name, 0, Position.Bias.Forward );
            if( path == null ){
                node = new DefaultMutableTreeNode(v.name);
                model.insertNodeInto( node, parent, 0 );
                parent = node;
            }
            else{
                parent = (DefaultMutableTreeNode)path.getLastPathComponent();
            }
            
            /* add url */
            model.insertNodeInto( new DefaultMutableTreeNode(post.page()), parent, 0 );
            
            AlertNodeObject alert = new AlertNodeObject();
            alert.post          = post;
            alert.vulnerability = v;
            alert.payload_idx   = payload;
            alert.match_idx     = match;
            alert.response      = response;
            
            this.alerts.add(alert);
            
            this.expandAll( true );
            this.repaint();
        }
    }
    
    public void expandAll(boolean expand) {
        TreeNode root = (TreeNode)this.getModel().getRoot();
    
        // Traverse tree from root
        expandAll( new TreePath(root), expand);
    }
    private void expandAll( TreePath parent, boolean expand) {
        // Traverse children
        TreeNode node = (TreeNode)parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e=node.children(); e.hasMoreElements(); ) {
                TreeNode n = (TreeNode)e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll( path, expand);
            }
        }
    
        // Expansion or collapse must be done bottom-up
        if (expand) {
            this.expandPath(parent);
        } else {
            this.collapsePath(parent);
        }
    }
}
