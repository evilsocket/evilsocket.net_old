/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.gui.renderers;

import iscan.gui.components.AlertTree;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;


public class AlertRenderer extends DefaultTreeCellRenderer {
    private ImageIcon root;
    private ImageIcon leaf;
    private ImageIcon verylow;
    private ImageIcon low;
    private ImageIcon medium;
    private ImageIcon high;
    
    private AlertTree tree;

    public AlertRenderer( AlertTree tree ){
        super();
        
        this.tree = tree;
        
        this.root = new ImageIcon(getClass().getResource("/alert.png"));
        this.leaf = new ImageIcon(getClass().getResource("/file.png"));
        this.verylow = new ImageIcon(getClass().getResource("/alert_vl.png"));
        this.low = new ImageIcon(getClass().getResource("/alert_l.png"));
        this.medium = new ImageIcon(getClass().getResource("/alert_m.png"));
        this.high = new ImageIcon(getClass().getResource("/alert_h.png"));
    }
    
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selection, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, selection, expanded, leaf, row, hasFocus);

        if (value != null) {
            setIcon(this.getIcon(value));
        }
        
        return this;
    }
    
    private ImageIcon getIcon(Object o){
        if( o != null ){
            if( ((TreeNode)o).getParent() == null || ((TreeNode)o).equals("Alerts") ){
                return this.root;
            }
            else if( ((TreeNode)o).isLeaf() ){
                return this.leaf;
            }
            else{
                String severity = this.tree.severityByName(((TreeNode)o).toString());
                if( severity != null ){
                    if( severity.contains("very low") ){
                        return this.verylow;
                    }
                    else if( severity.contains("low") ){
                        return this.low;
                    }
                    else if( severity.contains("medium") ){
                        return this.medium;
                    }
                    else if( severity.contains("high") ){
                        return this.high;
                    }
                }
            }
        }
        
        return null;
    }
}
