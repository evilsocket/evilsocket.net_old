/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.gui.renderers;

import iscan.utils.StringManager;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;

public class WebRenderer extends DefaultTreeCellRenderer {

    private ImageIcon fileicon;
    private ImageIcon foldericon;

    public WebRenderer() {
        super();
        this.fileicon = new ImageIcon(getClass().getResource("/file.png"));
        this.foldericon = new ImageIcon(getClass().getResource("/folder.png"));
    }

    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selection, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, selection, expanded, leaf, row, hasFocus);

        if (value != null) {
            if( this.isLeafNode(value) ){
                TreeNode node = (TreeNode)value;
                if (node.toString().startsWith("!")) {
                    setIcon(new ImageIcon(getClass().getResource("/alert.png")));
                } else {
                    setIcon(getFileIcon(node.toString()));
                }
            }
            else{
                setIcon(this.foldericon);
            }
        }
        return this;
    }
    
    private boolean isLeafNode(Object obj){
        TreeNode node = (TreeNode)obj;
        int children = node.getChildCount(), i;
        
        if( children <= 0 ){
            return true;
        }
        for( i = 0; i < children; i++ ){
            if( node.getChildAt(i).toString().startsWith("!") == false ){
                return false;
            }
        }
                
        return true;
    }

    private ImageIcon getFileIcon(String filename) {
        if (filename.contains(".")) {
            String ext = StringManager.getAfter( filename, "." );
            if (ext.equalsIgnoreCase("jpg") ||
                    ext.equalsIgnoreCase("jpeg") ||
                    ext.equalsIgnoreCase("png") ||
                    ext.equalsIgnoreCase("gif")) {
                return new ImageIcon(getClass().getResource("/image.png"));
            } else if (ext.equalsIgnoreCase("txt")) {
                return new ImageIcon(getClass().getResource("/text.png"));
            } 
            else if( ext.equalsIgnoreCase("swf") ){
                return new ImageIcon(getClass().getResource("/swf.png"));
            } else if (ext.equalsIgnoreCase("zip") ||
                       ext.equalsIgnoreCase("rar") ||
                       ext.equalsIgnoreCase("7z") ||
                       ext.equalsIgnoreCase("tar.gz") ||
                       ext.equalsIgnoreCase("tar.bz") ||
                       ext.equalsIgnoreCase("tar.bz2") ||
                       ext.equalsIgnoreCase("gz") ||
                       ext.equalsIgnoreCase("bz") ||
                       ext.equalsIgnoreCase("bz2") || 
                       ext.equalsIgnoreCase("ace") ) {
                return new ImageIcon(getClass().getResource("/archive.png"));
            } else if( ext.equalsIgnoreCase("jar") || ext.equalsIgnoreCase("class") || ext.equalsIgnoreCase("java") ){
                return new ImageIcon(getClass().getResource("/java.png"));
            } else if (ext.equalsIgnoreCase("exe") ||
                       ext.equalsIgnoreCase("bin") ||
                       ext.equalsIgnoreCase("sh") ) {
                return new ImageIcon(getClass().getResource("/exe.png"));
            }
        }

        return this.fileicon;
    }
}
