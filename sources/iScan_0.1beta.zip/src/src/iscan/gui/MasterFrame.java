/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */
package iscan.gui;

import iscan.SiteHistory;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.matchers.TextMatcherEditor;
import ca.odell.glazedlists.swing.AutoCompleteSupport;
import iscan.Configuration;
import iscan.Constants;
import iscan.Report;
import iscan.gui.components.AlertNodeObject;
import iscan.gui.components.AlertTree;
import iscan.gui.components.WebTree;
import iscan.gui.renderers.MsgTableRenderer;
import iscan.gui.renderers.AlertRenderer;
import iscan.gui.renderers.WebRenderer;
import iscan.Template;
import iscan.gui.renderers.ServiceRenderer;
import iscan.http.HttpInfo;
import iscan.http.crawler.SmartCrawler;
import iscan.http.crawler.SmartCrawlerCallback;
import iscan.http.requests.GetRequest;
import iscan.scanner.Scanner;
import iscan.scanner.ScannerCallback;
import iscan.tcp.PortScanner;
import iscan.tcp.Service;
import iscan.utils.StringManager;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author  evilsocket
 */
public class MasterFrame extends javax.swing.JFrame implements Runnable {

    private String lasturl = "";
    private AlertNodeObject lastalert = null;
    private Configuration configuration;
    private ScannerCallback scannercallback = new ScannerCallback(this);
    private Scanner scanner;
    private HttpInfo httpinfo;
    private SmartCrawlerCallback crawlercallback = new SmartCrawlerCallback(this);
    private SmartCrawler crawler = null;
    private AutoCompleteSupport autocompletesupport;
    private SiteHistory history;
    private PortScanner portscanner = null;
    private Vector<Service> tcpservices = null;
    
    public void manageException(Exception e) {
        e.printStackTrace();
        this.AddMsg(this.crawlercallback.now(), "!!! " + e.getMessage(), "Application Exception : " + e.toString());
        JOptionPane.showMessageDialog(null, StringManager.getAfter( e.getClass().toString(), "class " ) + " :\n\n" + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
    }

    protected class AlertTreeListener implements TreeSelectionListener {

        public AlertTreeListener() {
            super();
        }

        public void valueChanged(TreeSelectionEvent e) {
            TreeNode node = (TreeNode) e.getPath().getLastPathComponent();
            /* ignore details leaves */
            if (node.isLeaf() == true) {
                try {
                    if (node.getParent() != null) {
                        int relativeindex = node.getParent().getChildCount() - (node.getParent().getIndex(node) + 1);
                        /* revert index */
                        AlertNodeObject alert = alerttree.findAlert(relativeindex, node.getParent().toString());

                        lastalert = alert;
                        if (alert != null) {
                            Template tpl = new Template("data/templates/alertdetails.htm");
                            tpl.set("@PAGE", alert.toString());
                            tpl.set("@METHOD", alert.method());
                            tpl.set("@NAME", alert.vulnerability.name);
                            tpl.set("@FULLURL", alert.fullurl());
                            tpl.set("@SEVERITYCOLOR", alert.color());
                            tpl.set("@SEVERITY", alert.vulnerability.severity);
                            tpl.set("@DESCRIPTION", alert.vulnerability.description);

                            reportpanel.setText(tpl.html());
                        }
                    }
                } catch (Exception ex) {
                    manageException(ex);
                }
            }
        }
    }

    /** Creates new form MasterFrame */
    public MasterFrame() {
        initComponents();
        
        try {
            this.history = new SiteHistory("data/sitehistory.dat");
            final Vector sites = this.history.load();
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    autocompletesupport = AutoCompleteSupport.install(urlcombo, GlazedLists.eventList(sites));
                    autocompletesupport.setFilterMode(TextMatcherEditor.CONTAINS);
                }
            });

            this.msgtable.getColumnModel().getColumn(1).setCellRenderer(new MsgTableRenderer());
            this.msgtable.getColumnModel().getColumn(2).setPreferredWidth(180);
            this.msgtable.getColumnModel().getColumn(1).setPreferredWidth(861);
            this.wrntable.getColumnModel().getColumn(1).setCellRenderer(new MsgTableRenderer());
            this.wrntable.getColumnModel().getColumn(2).setPreferredWidth(180);
            this.wrntable.getColumnModel().getColumn(1).setPreferredWidth(861);
            this.errtable.getColumnModel().getColumn(1).setCellRenderer(new MsgTableRenderer());
            this.errtable.getColumnModel().getColumn(2).setPreferredWidth(180);
            this.errtable.getColumnModel().getColumn(1).setPreferredWidth(861);

            this.webtree.setCellRenderer(new WebRenderer());
            this.alerttree.setCellRenderer(new AlertRenderer(alerttree));
            this.alerttree.addTreeSelectionListener((TreeSelectionListener) (new AlertTreeListener()));
            this.svctree.setCellRenderer(new ServiceRenderer());

            this.reportpanel.setContentType("text/html");

            this.configuration = new Configuration("data/config.dat");
            this.scanner = new Scanner(this.scannercallback);

            Template tpl = new Template("data/templates/main.htm");
            tpl.set("@VERSION", Constants.version);
            tpl.set("@LOGO", getClass().getClassLoader().getResource("logo.png").toString());
            this.reportpanel.setText(tpl.html());

            ((DefaultTreeModel) this.alerttree.getModel()).setRoot(new DefaultMutableTreeNode("Alerts"));
            ((DefaultTreeModel) this.webtree.getModel()).setRoot(new DefaultMutableTreeNode("/"));
            ((DefaultTreeModel) this.svctree.getModel()).setRoot(new DefaultMutableTreeNode("Services"));

            this.tcpservices = new Vector<Service>();

            /* Center the frame */
            Dimension dim = getToolkit().getScreenSize();
            Rectangle abounds = getBounds();
            setLocation((dim.width - abounds.width) / 2, (dim.height - abounds.height) / 2);

            this.repaint();

        } catch (Exception e) {
            manageException(e);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        webtree = new WebTree();
        jScrollPane4 = new javax.swing.JScrollPane();
        infotable = new javax.swing.JTable();
        urlcombo = new javax.swing.JComboBox();
        jToolBar1 = new javax.swing.JToolBar();
        savebtn = new javax.swing.JButton();
        configbtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        fullcheck = new javax.swing.JRadioButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        fastcheck = new javax.swing.JRadioButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        startbtn = new javax.swing.JButton();
        stopbtn = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        alerttree = new AlertTree();
        jScrollPane3 = new javax.swing.JScrollPane();
        reportpanel = new javax.swing.JEditorPane();
        tabs = new javax.swing.JTabbedPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        msgtable = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        wrntable = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        errtable = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        svctree = new javax.swing.JTree();
        jToolBar2 = new javax.swing.JToolBar();
        jLabel1 = new javax.swing.JLabel();
        scan_stopbtn = new javax.swing.JButton();
        psbar = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("iScan Web Vulnerability Scanner");
        setResizable(false);

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        webtree.setAutoscrolls(true);
        webtree.setDoubleBuffered(true);
        webtree.setShowsRootHandles(false);
        jScrollPane1.setViewportView(webtree);

        infotable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Info", "Value"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        infotable.setShowHorizontalLines(false);
        infotable.setShowVerticalLines(false);
        jScrollPane4.setViewportView(infotable);

        urlcombo.setEditable(true);
        urlcombo.setMinimumSize(new java.awt.Dimension(150, 150));

        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);

        savebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/save.png"))); // NOI18N
        savebtn.setBorder(null);
        savebtn.setFocusable(false);
        savebtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        savebtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        savebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebtnActionPerformed(evt);
            }
        });
        jToolBar1.add(savebtn);

        configbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/settings.png"))); // NOI18N
        configbtn.setBorder(null);
        configbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                configbtnActionPerformed(evt);
            }
        });
        jToolBar1.add(configbtn);
        jToolBar1.add(jSeparator1);

        fullcheck.setSelected(true);
        fullcheck.setText("Full");
        fullcheck.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        fullcheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fullcheckActionPerformed(evt);
            }
        });
        jToolBar1.add(fullcheck);
        jToolBar1.add(jSeparator3);

        fastcheck.setText("Fast");
        fastcheck.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        fastcheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fastcheckActionPerformed(evt);
            }
        });
        jToolBar1.add(fastcheck);
        jToolBar1.add(jSeparator2);

        startbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/start.png"))); // NOI18N
        startbtn.setBorder(null);
        startbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startbtnActionPerformed(evt);
            }
        });
        jToolBar1.add(startbtn);

        stopbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/stop.png"))); // NOI18N
        stopbtn.setBorder(null);
        stopbtn.setEnabled(false);
        stopbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopbtnActionPerformed(evt);
            }
        });
        jToolBar1.add(stopbtn);

        alerttree.setShowsRootHandles(false);
        jScrollPane5.setViewportView(alerttree);

        reportpanel.setEditable(false);
        reportpanel.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                reportpanelHyperlinkUpdate(evt);
            }
        });
        jScrollPane3.setViewportView(reportpanel);

        tabs.setBorder(null);
        tabs.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);

        msgtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Time", "Message", "Details"
            }
        ));
        jScrollPane2.setViewportView(msgtable);

        tabs.addTab("messages", new javax.swing.ImageIcon(getClass().getResource("/alert_l.png")), jScrollPane2); // NOI18N

        wrntable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Time", "Warning", "Details"
            }
        ));
        jScrollPane6.setViewportView(wrntable);

        tabs.addTab("warnings", new javax.swing.ImageIcon(getClass().getResource("/alert_m.png")), jScrollPane6); // NOI18N

        errtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Time", "Error", "Details"
            }
        ));
        jScrollPane7.setViewportView(errtable);

        tabs.addTab("errors", new javax.swing.ImageIcon(getClass().getResource("/alert_h.png")), jScrollPane7); // NOI18N

        svctree.setScrollsOnExpand(true);
        svctree.setShowsRootHandles(false);
        svctree.setToggleClickCount(1);
        jScrollPane8.setViewportView(svctree);

        jToolBar2.setBorder(null);
        jToolBar2.setFloatable(false);
        jToolBar2.setRollover(true);

        jLabel1.setText("TCP Services Discovery");
        jToolBar2.add(jLabel1);

        scan_stopbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/stop.png"))); // NOI18N
        scan_stopbtn.setBorder(null);
        scan_stopbtn.setEnabled(false);
        scan_stopbtn.setFocusable(false);
        scan_stopbtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        scan_stopbtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        scan_stopbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stop_scanbtnActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(urlcombo, 0, 836, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jToolBar1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(tabs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1066, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 248, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jScrollPane3)
                            .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 574, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                            .add(psbar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                                .add(jToolBar2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(scan_stopbtn)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(urlcombo, 0, 15, Short.MAX_VALUE)
                    .add(jToolBar1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 542, Short.MAX_VALUE)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane4, 0, 0, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 220, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(scan_stopbtn, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jToolBar2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(psbar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE))
                            .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tabs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 130, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public Scanner scanner() {
        return this.scanner;
    }
    
    public JProgressBar pscanbar(){
        return this.psbar;
    }
    
    public JButton pscanbutton(){
        return this.scan_stopbtn;
    }
    
    private void resetStatus() throws Exception {
        this.scanner.reset();
        this.alerttree.clear();
        ((DefaultTreeModel) this.svctree.getModel()).setRoot(new DefaultMutableTreeNode("Services"));
        this.tcpservices.clear();
        this.psbar.setValue(0);
        Template tpl = new Template("data/templates/main.htm");
        tpl.set("@VERSION", Constants.version );
        tpl.set("@LOGO", getClass().getClassLoader().getResource("logo.png").toString() );
        
        this.reportpanel.setText(tpl.html());
        
        this.alerttree.reset();
        this.webtree.reset();
        ((DefaultTableModel) this.msgtable.getModel()).setRowCount(0);
        ((DefaultTableModel) this.wrntable.getModel()).setRowCount(0);
        ((DefaultTableModel) this.errtable.getModel()).setRowCount(0);
        this.tabs.setTitleAt( 0, "messages" );
        this.tabs.setTitleAt( 1, "warnings" );
        this.tabs.setTitleAt( 2, "errors" );
        ((DefaultTableModel) this.infotable.getModel()).setRowCount(0);
        
    }
    
    private void enableStatus(){
        this.urlcombo.setEnabled(true);
        this.startbtn.setEnabled(true);
        this.savebtn.setEnabled(true);
        this.configbtn.setEnabled(true);
        this.stopbtn.setEnabled(false);
    }
    
    private void disableStatus(){
        this.urlcombo.setEnabled(false);
        this.startbtn.setEnabled(false);
        this.savebtn.setEnabled(false);
        this.configbtn.setEnabled(false);
        this.stopbtn.setEnabled(true);
    }

    public void run() {
        try {
            resetStatus();
            
            String url = (String) this.urlcombo.getSelectedItem();
            this.history.add(url);
            final Vector sites = this.history.load();
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    autocompletesupport.uninstall();
                    autocompletesupport = AutoCompleteSupport.install(urlcombo, GlazedLists.eventList(sites));
                }
            });

            if (url.contains("://") == false) {
                url = Constants.default_schema + "://" + url;
            }
            this.lasturl = url;

            final String asyncurl = url;
            final MasterFrame asyncframe = this;
            Thread collecthttpinfothread = new Thread(new Runnable() {

                public void run() {
                    try {
                        httpinfo = new HttpInfo(asyncurl);

                        if( httpinfo.hostname.isEmpty() == false ){
                            AddInfo("Host Name", httpinfo.hostname);
                            
                            if( JOptionPane.showConfirmDialog( null, "Do you want to scan the host for open tcp ports ?", "Port Scan",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION ){
                                portscanner = new PortScanner(asyncframe);
                                portscanner.start(httpinfo.hostname);
                                scan_stopbtn.setEnabled(true);
                            }   
                        }
                        if(httpinfo.ipaddress.isEmpty() == false ){
                            AddInfo("Address", httpinfo.ipaddress);
                        }
                        if(httpinfo.server.isEmpty() == false ){
                            AddInfo("Server Banner", httpinfo.server);
                        }
                        if(httpinfo.methods.isEmpty() == false ){
                            AddInfo("Allowed Methods", httpinfo.methods);
                        }
                    } catch (Exception e) {
                        manageException(e);
                    }
                }
            });
            collecthttpinfothread.start();


            this.crawler = new SmartCrawler( url, this.crawlercallback, (this.fastcheck.isSelected() ? SmartCrawler.FAST_CRAWL : SmartCrawler.FULL_CRAWL));
            this.crawler.start();

            this.AddInfo("Crawl Time", this.crawler.getCrawlTime());

            final Vector httpobjects = this.crawler.getObjects();
            final int n = httpobjects.size(), i;
            final ScanningFrame scanningframe = new ScanningFrame(this);
            scanningframe.bar.setMinimum(0);
            scanningframe.bar.setMaximum(n);

            Thread showscanningthread = new Thread(new Runnable() {
                public void run() {
                    try
                    {
                        scanningframe.setVisible(true);

                        for( int i = 0; i < n && scanner.isRunning(); i++) {
                            scanningframe.bar.setValue(i + 1);
                            scanningframe.bar.repaint();
                            scanner.scan(httpobjects.elementAt(i));
                        }
                        
                        int pending = 0;
                        scanningframe.bar.setMaximum(scanner.getPendingOperations());
                        scanningframe.bar.setValue(0);
                        while( (pending = scanner.getPendingOperations()) > 0 ){
                            scanningframe.text.setText("Waiting for " + pending + " thread" + (pending > 1 ? "s" : "") + " to finish ...");
                            scanningframe.bar.setValue( scanningframe.bar.getMaximum() - pending );
                            Thread.sleep(100);
                        }
                        
                        scanner.waitForAsyncOperations();  
                    } 
                    catch (Exception e) {            
                        manageException(e);
                    }
                    finally{
                        scanningframe.dispose();
                        scanningframe.setVisible(false);
                        enableStatus();
                        repaint();
                    }
                }
            });
            
            this.disableStatus();
            showscanningthread.start();
            
            this.repaint();
        } catch (Exception e) {
            manageException(e);
        }
        finally{
            this.stopbtn.setEnabled(false);
            this.repaint();
        }
    }

private void stop_scanbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stop_scanbtnActionPerformed
    this.portscanner.stop();
    this.scan_stopbtn.setEnabled(false);
}//GEN-LAST:event_stop_scanbtnActionPerformed

private void startbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startbtnActionPerformed
    this.urlcombo.actionPerformed(null);
    if( this.urlcombo.getModel().getSelectedItem() == null || this.urlcombo.getModel().getSelectedItem().toString().length() <= 0 ){
        enableStatus();
        JOptionPane.showMessageDialog(null, "No target specified .", "ERROR", JOptionPane.WARNING_MESSAGE);
        return;
    }
    disableStatus();
    (new Thread(this)).start();
}//GEN-LAST:event_startbtnActionPerformed

private void stopbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopbtnActionPerformed
    if (this.crawler != null) {
        this.crawler.stop();
    }
    enableStatus();
    this.repaint();
}//GEN-LAST:event_stopbtnActionPerformed

private void fullcheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fullcheckActionPerformed
    this.fastcheck.setSelected(false);
    this.fullcheck.setSelected(true);
}//GEN-LAST:event_fullcheckActionPerformed

private void fastcheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fastcheckActionPerformed
    this.fullcheck.setSelected(false);
    this.fastcheck.setSelected(true);
}//GEN-LAST:event_fastcheckActionPerformed

private void configbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_configbtnActionPerformed
    SettingsFrame settingsframe = new SettingsFrame();
    settingsframe.setVisible(true);
}//GEN-LAST:event_configbtnActionPerformed

private void reportpanelHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {//GEN-FIRST:event_reportpanelHyperlinkUpdate
    if( evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED ){
        if( this.lastalert != null && evt.getDescription().equals("@HTTPEDITOR")){
            HttpFrame hf = new HttpFrame( this.lastalert, StringManager.getBetween( lasturl, "://", "/") );
            hf.setVisible(true);
        }
    }
}//GEN-LAST:event_reportpanelHyperlinkUpdate

private void savebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebtnActionPerformed
    if( this.crawler == null ){
        JOptionPane.showMessageDialog(null, "Please complete a scan first .", "ERROR", JOptionPane.WARNING_MESSAGE);
        return;
    }
    try
    {
        JFileChooser fileChooser = new JFileChooser("Save as ...");
        if( fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION ){
            Report report = new Report();
            report.setHeader( "@CRAWLMODE",    (this.crawler.style() == SmartCrawler.FAST_CRAWL ? "Fast" : "Full") );
            report.setHeader( "@HOSTNAME",     this.httpinfo.hostname );
            report.setHeader( "@ADDRESS",      this.httpinfo.ipaddress );
            report.setHeader( "@SERVERBANNER", this.httpinfo.server );
            report.setHeader( "@HTTPOBJECTS",  String.valueOf(this.crawler.getObjects().size()) );
            report.setHeader( "@GETS",         String.valueOf(this.crawlercallback.gets) );
            report.setHeader( "@POSTS",        String.valueOf(this.crawlercallback.posts) );
            report.setHeader( "@DEADLINKS",    String.valueOf(this.crawlercallback.deadlinks) );
            report.setHeader( "@CRAWLTIME",    this.crawler.getCrawlTime() );
            report.setHeader( "@ALERTS",       String.valueOf(this.alerttree.alerts().size()) );
            for( int i = 0; i < this.alerttree.alerts().size(); i++ ){
                report.addAlert(this.alerttree.alerts().get(i));
            }
        
            String filename = fileChooser.getSelectedFile().getPath();

            filename = (filename.endsWith(".htm") ? filename : filename + ".htm" );

            report.save(filename);
            
            JOptionPane.showMessageDialog( null, "Report saved to " + filename + " ." );
        }
    }
    catch( Exception e ){
        manageException(e);
    }
}//GEN-LAST:event_savebtnActionPerformed
                                         
    public void AddNode( GetRequest url ){
        this.webtree.addUrl(url);
        this.webtree.repaint();
    }
    
    public void AddInfo( String name, String value ){
        DefaultTableModel model = (DefaultTableModel)this.infotable.getModel();
        model.addRow( new Object[]{ name, value } );
        this.infotable.repaint();
    }
    
    public void AddMsg( String time, String msg, String details ){
        JTable            table = null;
        DefaultTableModel model = null;
        
        if( msg.startsWith("!!!") ){
            table = this.errtable;
            model = (DefaultTableModel)table.getModel();
            model.insertRow( 0, new Object[]{ time, msg, details } );
            tabs.setTitleAt( 2, "errors (" + errtable.getRowCount() + ")" );
            tabs.repaint();
        }
        else if( msg.startsWith("!!?") ){
            table = this.wrntable;
            model = (DefaultTableModel)table.getModel();
            model.insertRow( 0, new Object[]{ time, msg, details } );
            tabs.setTitleAt( 1, "warnings (" + wrntable.getRowCount() + ")" );
            tabs.repaint();
        }
        else{
            table = this.msgtable;
            model = (DefaultTableModel)table.getModel();
            model.insertRow( 0, new Object[]{ time, msg, details } );
            tabs.setTitleAt( 0, "messages (" + msgtable.getRowCount() + ")" );
            tabs.repaint();
        }
        
        table.repaint();
    }
    
    public synchronized void addService(Service s){
        DefaultTreeModel       model  = (DefaultTreeModel)svctree.getModel();
        TreePath               path   = new TreePath((TreeNode)svctree.getModel().getRoot());
        DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getRoot(),
                               node   = null;

       
        node = new DefaultMutableTreeNode(s.name.toUpperCase());
        model.insertNodeInto( node, parent, 0 );
        parent = node;
        
        model.insertNodeInto( new DefaultMutableTreeNode("Port : " + s.port), parent, 0 );
        model.insertNodeInto( new DefaultMutableTreeNode(s.description), parent, 0 );
        
        this.tcpservices.add(s);
        
        svctree.expandPath(path);
        svctree.repaint();
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public AlertTree alerttree;
    private javax.swing.JButton configbtn;
    private javax.swing.JTable errtable;
    private javax.swing.JRadioButton fastcheck;
    private javax.swing.JRadioButton fullcheck;
    private javax.swing.JTable infotable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JTable msgtable;
    private javax.swing.JProgressBar psbar;
    private javax.swing.JEditorPane reportpanel;
    private javax.swing.JButton savebtn;
    private javax.swing.JButton scan_stopbtn;
    private javax.swing.JButton startbtn;
    private javax.swing.JButton stopbtn;
    private javax.swing.JTree svctree;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JComboBox urlcombo;
    public WebTree webtree;
    private javax.swing.JTable wrntable;
    // End of variables declaration//GEN-END:variables

}
