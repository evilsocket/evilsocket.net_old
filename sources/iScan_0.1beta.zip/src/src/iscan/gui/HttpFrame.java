/*
 * HttpFrame.java
 *
 * Created on 26 giugno 2008, 14.19
 */

package iscan.gui;

import iscan.Configuration;
import iscan.gui.components.AlertNodeObject;
import iscan.utils.StringManager;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URLEncoder;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author  evilsocket
 */
public class HttpFrame extends javax.swing.JFrame {
    private String host = "";
    
    /** Creates new form HttpFrame */
    public HttpFrame( AlertNodeObject alertnode, String roothost ) {
        initComponents();
        
        try{            
            Configuration    config = Configuration.getInstance();
            DefaultTableModel model =  (DefaultTableModel)this.requesttable.getModel();
            this.host = roothost;

            if( alertnode.method().equals("GET") ){
                String host = StringManager.getBetween( alertnode.get.url(), "://", "/" ),
                       page = StringManager.getAfter( alertnode.get.longurl(), host );

                model.addRow( new Object[]{ "GET", page + " HTTP/1.1" } );
                if( config.useragent.isEmpty() == false  ){
                    model.addRow( new Object[]{ "User-Agent", config.useragent } );
                }
                if( config.referer.isEmpty() == false  ){
                    model.addRow( new Object[]{ "Referer", config.referer } );
                }
                else{
                    model.addRow( new Object[]{ "Referer", alertnode.get.url() } );
                }
                model.addRow( new Object[]{ "Host" , host } );
                model.addRow( new Object[]{ "Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" } );
                model.addRow( new Object[]{ "Keep-Alive", "300" } );
                model.addRow( new Object[]{ "Connection", "keep-alive" } );
                model.addRow( new Object[]{ "Cache-Control", "max-age=0" } );
            }
            else if( alertnode.method().equals("POST") ){
                String host = StringManager.getBetween( alertnode.post.action(), "://", "/" ),
                       page = StringManager.getAfter( alertnode.post.action(), host );

                model.addRow( new Object[]{ "POST", page + " HTTP/1.1" } );
                if( config.useragent.isEmpty() == false  ){
                    model.addRow( new Object[]{ "User-Agent", config.useragent } );
                }
                if( config.referer.isEmpty() == false  ){
                    model.addRow( new Object[]{ "Referer", config.referer } );
                }
                else{
                    model.addRow( new Object[]{ "Referer", alertnode.get.url() } );
                }
                model.addRow( new Object[]{ "Host", host } );
                model.addRow( new Object[]{ "Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" } );
                model.addRow( new Object[]{ "Keep-Alive", "300" } );
                model.addRow( new Object[]{ "Connection", "keep-alive" } );
                model.addRow( new Object[]{ "Cache-Control", "max-age=0" } );

                String post = new String();
                for( int i = 0; i < alertnode.post.elements(); i++ ){
                    post += URLEncoder.encode( alertnode.post.getArgument(i), "UTF-8")   + "=" +  
                            URLEncoder.encode( alertnode.post.getValue(i), "UTF-8") + "&";
                }
                model.addRow( new Object[]{ "Content-Length", String.valueOf(post.length()) } );
                model.addRow( new Object[]{ "", post } );
            }
            else if( alertnode.method().equals("POST") ){
                model.addRow( new Object[]{ "HEAD", "/ HTTP/1.1" } );
                if( config.useragent.isEmpty() == false  ){
                    model.addRow( new Object[]{ "User-Agent", config.useragent } );
                }
                if( config.referer.isEmpty() == false  ){
                    model.addRow( new Object[]{ "Referer", config.referer } );
                }
                else{
                    model.addRow( new Object[]{ "Referer", roothost } );
                }
                model.addRow( new Object[]{ "Host", roothost } );
                model.addRow( new Object[]{ "Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" } );
                model.addRow( new Object[]{ "Keep-Alive", "300" } );
                model.addRow( new Object[]{ "Connection", "keep-alive" } );
                model.addRow( new Object[]{ "Cache-Control", "max-age=0" } );

                String post = new String();
                for( int i = 0; i < alertnode.post.elements(); i++ ){
                    post += URLEncoder.encode( alertnode.post.getArgument(i), "UTF-8")   + "=" +  
                            URLEncoder.encode( alertnode.post.getValue(i), "UTF-8") + "&";
                }
                model.addRow( new Object[]{ "Content-Length", String.valueOf(post.length()) } );
                model.addRow( new Object[]{ "", post } );
            }
            
            /* Center the frame */
            Dimension dim = getToolkit().getScreenSize();
            Rectangle abounds = getBounds();
            setLocation((dim.width - abounds.width) / 2, (dim.height - abounds.height) / 2);
            
            this.requesttable.repaint();
        }
        catch( Exception e ){
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void disableStatus(){
        this.launchbtn.setEnabled(false);
        this.addbtn.setEnabled(false);
        this.delbtn.setEnabled(false);
        this.requesttable.setEnabled(false);
        this.buffertable.setEnabled(false);
        this.repaint();
    }
    
    private void enableStatus(){
        this.launchbtn.setEnabled(true);
        this.addbtn.setEnabled(true);
        this.delbtn.setEnabled(true);
        this.requesttable.setEnabled(true);
        this.buffertable.setEnabled(true);
        this.repaint();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        requesttable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        buffertable = new javax.swing.JTable();
        launchbtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        addbtn = new javax.swing.JButton();
        delbtn = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        headertable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("HTTP Editor");
        setResizable(false);

        requesttable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Parameter", "Value"
            }
        ));
        requesttable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(requesttable);
        requesttable.getColumnModel().getColumn(0).setPreferredWidth(120);
        requesttable.getColumnModel().getColumn(1).setPreferredWidth(447);

        buffertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Response Buffer"
            }
        ));
        buffertable.setShowHorizontalLines(false);
        buffertable.setShowVerticalLines(false);
        jScrollPane2.setViewportView(buffertable);

        launchbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/start.png"))); // NOI18N
        launchbtn.setBorder(null);
        launchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                launchbtnActionPerformed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        addbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/add.png"))); // NOI18N
        addbtn.setBorder(null);
        addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtnActionPerformed(evt);
            }
        });

        delbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/del.png"))); // NOI18N
        delbtn.setBorder(null);
        delbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delbtnActionPerformed(evt);
            }
        });

        headertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Response Header"
            }
        ));
        headertable.setShowHorizontalLines(false);
        headertable.setShowVerticalLines(false);
        jScrollPane3.setViewportView(headertable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(launchbtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addbtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(delbtn))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addbtn)
                            .addComponent(delbtn)))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(launchbtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void launchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_launchbtnActionPerformed
        try{
            Thread thread = new Thread( new Runnable() {
                public void run() {
                    try{
                        disableStatus();
                        
                        Socket socket = new Socket( InetAddress.getByName(host), 80 );

                        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                        DefaultTableModel in  = (DefaultTableModel)requesttable.getModel(),
                                          header = (DefaultTableModel)headertable.getModel(),
                                          buffer = (DefaultTableModel)buffertable.getModel();
                        for( int i = 0; i < requesttable.getRowCount(); i++ ){
                            String key = (String)in.getValueAt(i,0),
                                   val = (String)in.getValueAt(i,1);

                            requesttable.setRowSelectionInterval(i,i);
                            requesttable.repaint();
                            
                            /* first row *should* be the method */
                            if( i == 0 ){
                                writer.write( key + " " + val + "\r\n");
                            }
                            else if( key.isEmpty() == false ){
                                writer.write( key + ": " + val + "\r\n");
                            }
                            else if( val.isEmpty() == false ){
                                writer.write( val + "\r\n");
                            }
                            else{
                                // skip stupid empty rows -.-
                            }
                        }
                        writer.write("\r\n");
                        writer.flush();
                        
                        buffer.setRowCount(0);
                        header.setRowCount(0);

                        String line;
                        boolean headerdone = false;
                        while( (line = reader.readLine()) != null) {
                            if( headerdone == false ){
                                if( line.isEmpty() || line.equals("\r\n") ){
                                    headerdone = true;
                                }
                                else{
                                    header.addRow( new Object[]{ line } );
                                    headertable.repaint();
                                }
                            }
                            else{
                               buffer.addRow( new Object[]{ line } );
                               buffertable.repaint();
                            }
                        }

                        enableStatus();
                        
                        socket.close();
                    }
                    catch( Exception e ){
                        JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                    finally{
                        enableStatus();
                    }
                }
            });
            thread.start();
        }
        catch( Exception e ){
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_launchbtnActionPerformed

    private void addbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtnActionPerformed
        int row = 0;
        if( (row = this.requesttable.getSelectedRow()) != -1 ){
            DefaultTableModel model = (DefaultTableModel)requesttable.getModel(); 
            model.insertRow( row + 1, new Object[]{ "", "" });
        }
        else{
            JOptionPane.showMessageDialog(null, "Please select a row to insert new values after .", "Warning", JOptionPane.WARNING_MESSAGE );
        }
    }//GEN-LAST:event_addbtnActionPerformed

    private void delbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delbtnActionPerformed
        int row = 0;
        if( (row = this.requesttable.getSelectedRow()) != -1 ){
            DefaultTableModel model = (DefaultTableModel)requesttable.getModel(); 
            model.removeRow(row);
        }
        else{
            JOptionPane.showMessageDialog(null, "Please select a row to delete .", "Warning", JOptionPane.WARNING_MESSAGE );
        }
    }//GEN-LAST:event_delbtnActionPerformed
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbtn;
    private javax.swing.JTable buffertable;
    private javax.swing.JButton delbtn;
    private javax.swing.JTable headertable;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton launchbtn;
    private javax.swing.JTable requesttable;
    // End of variables declaration//GEN-END:variables
    
}
