/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.utils;

import java.util.Random;
import java.util.Vector;

public class StringManager {

    public static String getAfter(String str, String token ) {
        if (str.contains(token)) {
            str = str.substring(str.indexOf(token) + token.length());
        }
        return str;
    }
    
    public static String getAfterOrEmpty(String str, String token ) {
        String ret = getAfter(str,token);
        if( ret.equals(str) ){
            return "";
        }
        else{
            return ret;
        }
    }

    public static String getBefore(String str, String token) {
        if (str.contains(token)) {
            str = str.substring(0, str.indexOf(token));
        }
        return str;
    }
    
    public static String getBeforeOrEmpty(String str, String token) {
        String ret = getBefore(str,token);
        if( ret.equals(str) ){
            return "";
        }
        else{
            return ret;
        }
    }

    public static String getBetween(String str, String head, String tail) {
        return getBefore(StringManager.getAfter(str, head), tail);
    }
    
    public static String getBetweenOrEmpty(String str, String head, String tail) {
        return getBeforeOrEmpty(StringManager.getAfterOrEmpty(str, head), tail);
    }

    public static String getRandomString(int length) {
        String sKey = "";
        Random random = new Random(System.currentTimeMillis());
        long r1 = random.nextLong();
        long r2 = random.nextLong();
        String hash1 = Long.toHexString(r1);
        String hash2 = Long.toHexString(r2);
        sKey = hash1 + hash2;
        if (sKey.length() > length) {
            sKey = sKey.substring(0, length);
        }
        return sKey.toUpperCase();
    }
    
    public static String fixRelativeUrl( String fullurl ) throws Exception {
        if( fullurl.contains("..") || fullurl.contains("./") ){
            String proto   = getBeforeOrEmpty( fullurl, "://" ),
                   host    = getBetween( fullurl, "://", "/" ),
                   urlpart = getBefore( getAfter( fullurl, "://" ), "?" ),
                   varpart = getAfterOrEmpty( fullurl, "?" );
        
            String dirs[] = urlpart.split("/");
            String last   = "";
            Vector<String> objs = new Vector();
            for( String dir : dirs ){
                if( dir.equals("..") ){
                    if( last.contains(host) == false ){
                        objs.remove(last);
                    }
                }
                else if( dir.equals(".") || dir.isEmpty() ){

                }
                else{
                    objs.add(dir);
                    last = dir;
                } 
            }
            // rebuild url
            urlpart = "";
            for( int i = 0; i < objs.size(); i++ ){
                urlpart += objs.get(i) + (i == (objs.size() - 1) ? "" : "/");
            }
            
            return (proto.isEmpty() ? "" : proto + "://" ) + urlpart + (varpart.isEmpty() ? "" : "?" + varpart );
        }
        else{
            return fullurl;
        }
    }
}
