/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.scanner;

import iscan.http.HttpManager;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.scanner.db.Database;
import iscan.scanner.db.Match;
import iscan.scanner.db.Payload;
import iscan.scanner.db.Vulnerability;
import iscan.utils.StringManager;
import java.util.Vector;

public class Scanner {

    private ScannerCallback callback;
    private Vector<Thread> runningthreads;
    private Vector<Vulnerability> filestocheck;
    private Vector<Vulnerability> headstocheck;
    private Vector<Vulnerability> vulnerabilities;
    private boolean headscopechecked = false;
    private boolean httpscopechecked = false;
    private boolean stop = false;

    public Scanner(ScannerCallback callback) throws Exception {
        this.callback = callback;
        Database db = new Database("data/db/");
        Vector<Vulnerability> v = db.vulnerabilities;

        this.runningthreads = new Vector<Thread>();
        this.vulnerabilities = new Vector<Vulnerability>();
        this.headstocheck = new Vector<Vulnerability>();
        this.filestocheck = new Vector<Vulnerability>();

        int vi, ploads = 0;
        for (vi = 0; vi < v.size(); vi++) {
            Vulnerability vuln = v.elementAt(vi);
            String scope = vuln.payloads.get(0).scopes.get(0).toString().toUpperCase();
            if (scope.equals("HTTP")) {
                this.filestocheck.add(vuln);
            } else if (scope.equals("HEADER")) {
                this.headstocheck.add(vuln);
            } else {
                this.vulnerabilities.add(vuln);
            }
            ploads += vuln.payloads.size();
        }

        this.callback.onDatabaseLoaded(this.vulnerabilities.size() + this.headstocheck.size() + this.filestocheck.size(), ploads);
    }

    public void reset() {
        this.headscopechecked = false;
        this.httpscopechecked = false;
        this.stop             = false;
        this.runningthreads.clear();
    }

    public boolean isRunning() {
        return (this.stop == false);
    }

    public synchronized int getPendingOperations() throws Exception {
        int operations = 0;
        for (int i = 0; i < this.runningthreads.size(); i++) {
            if (this.runningthreads.elementAt(i).isAlive()) {
                operations++;
            }
        }
        return operations;
    }

    public synchronized void waitForAsyncOperations() throws Exception {
        for (int i = 0; i < this.runningthreads.size(); i++) {
            if (this.runningthreads.elementAt(i).isAlive()) {
                this.runningthreads.elementAt(i).join();
            }
        }
    }

    private synchronized void checkFilesystemThread(Object httpobject) throws Exception {
        final Object asyncobj = httpobject;
        if (this.httpscopechecked == false) {
            this.httpscopechecked = true;
            Thread fsthread = new Thread(new Runnable() {

                public void run() {
                    try {
                        HTTPScopeScan(asyncobj);
                    } catch (Exception e) {

                    }
                }
            });
            fsthread.start();
            this.runningthreads.add(fsthread);
        }
    }
    
    private synchronized void checkHeaderThread(Object httpobject) throws Exception {
        final Object asyncobj = httpobject;
        if (this.headscopechecked == false) {
            this.headscopechecked = true;
            Thread hthread = new Thread(new Runnable() {
                public void run() {
                    try {
                        HEADERScopeScan(asyncobj);
                    } catch (Exception e) {

                    }
                }
            });
            hthread.start();
            this.runningthreads.add(hthread);
        }
    }

    public synchronized void scan(Object httpobject) throws Exception {
        this.checkFilesystemThread(httpobject);
        this.checkHeaderThread(httpobject);

        final Object asyncobj = httpobject;
        Thread thread = new Thread(new Runnable() {

            public void run() {
                try {
                    if (asyncobj instanceof GetRequest) {
                        GETScopeScan((GetRequest) asyncobj);
                    } else {
                        POSTScopeScan((PostRequest) asyncobj);
                    }
                } catch (Exception e) {

                }
            }
        });

        thread.start();
        this.runningthreads.add(thread);
    }

    public void stop() {
        this.stop = true;
    }

    private void HTTPScopeScan(Object rootobject) throws Exception {
        GetRequest file;
        String root;
        if (rootobject instanceof GetRequest) {
            root = ((GetRequest) rootobject).host();
        } else {
            root = ((PostRequest) rootobject).host();
        }

        String e404 = HttpManager.get404Payload(root);

        int vi, pi;
        for (vi = 0; vi < this.filestocheck.size() && this.isRunning(); vi++) {
            Vulnerability vuln = filestocheck.elementAt(vi);
            for (pi = 0; pi < vuln.payloads.size() && this.isRunning(); pi++) {
                Payload payload = vuln.payloads.elementAt(pi);
                file = new GetRequest(root, payload.data);
                this.callback.onGetObject(file);
                try {
                    String response = file.execute();
                    if (e404 == null || response.contains(e404) == false) {
                        this.callback.onGetMatch(file.copy(), response, vuln, pi, 0);
                    }
                } catch (Exception e) {

                }
            }
        }
    }

    private void HEADERScopeScan(Object rootobject) throws Exception {
        String host;
        if (rootobject instanceof GetRequest) {
            host = ((GetRequest) rootobject).host();
        } else {
            host = ((PostRequest) rootobject).host();
        }
        String header = null;
        try {
                header = HttpManager.getHttpHeader(host);
        } catch (Exception e) {

        }
        finally{
            if( header != null ){
                int vi, mi;
                for (vi = 0; vi < this.headstocheck.size() && this.isRunning(); vi++) {
                    Vulnerability vuln = this.headstocheck.elementAt(vi);
                    /* Payload is always :
                     *  <payload scope="HEADER">/</payload>
                     * so im gonna ignore that .
                     */
                    
                    /* loop each matcher */
                    for( mi = 0; mi < vuln.matches.size(); mi++ ){
                        Match match = vuln.matches.elementAt(mi);
                        /* finally, we've got a match ? */
                        if (header != null && match.match(header) == true) {
                            this.callback.onHeadermatch( new GetRequest(host,"") , header, vuln, 0, mi);
                            return;
                        }
                    }
                }
            }
        }
    }

    private void GETScopeScan(GetRequest get) throws Exception {
        if (get.elements() > 0 && this.isRunning()) {
            this.callback.onGetObject(get);
            int vi, pi, ai, mi;
            /* loop each vulnerability */
            for (vi = 0; vi < this.vulnerabilities.size() && this.isRunning(); vi++) {
                Vulnerability vuln = this.vulnerabilities.elementAt(vi);
                /* loop each payload */
                for (pi = 0; pi < vuln.payloads.size() && this.isRunning(); pi++) {
                    Payload payload = vuln.payloads.elementAt(pi);
                    /* is a GET payload ? */
                    if ((payload.scopes.contains("GET") || payload.scopes.contains("get")) && this.isRunning()) {
                        /* loop each request argument */
                        for (ai = 0; ai < get.elements() && this.isRunning(); ai++) {
                            String original = get.getValue(ai);
                            String random = null;
                            if (payload.data.contains("@RANDOM")) {
                                random = StringManager.getRandomString(25);
                                payload.data = payload.data.replaceAll("@RANDOM", random);
                            }
                            get.setValue(ai, payload.data);
                            try {
                                String response = get.execute();
                                /* loop each matcher */
                                for (mi = 0; mi < vuln.matches.size(); mi++) {
                                    Match match = vuln.matches.elementAt(mi);
                                    if (match.data.contains("@PAYLOAD")) {
                                        match.data = match.data.replaceAll("@PAYLOAD", payload.data);
                                    }
                                    if (match.data.contains("@RANDOM") && random != null) {
                                        match.data = match.data.replaceAll("@RANDOM", random);
                                    }

                                    /* finally, we've got a match ? */
                                    if (match.match(response) == true) {
                                        this.callback.onGetMatch(get.copy(), response, vuln, pi, mi);
                                        get.setValue(ai, original);
                                        return;
                                    }
                                }
                            } catch (Exception e) {
                                this.callback.onConnectionError(get.page(), e.getMessage());
                            }

                            get.setValue(ai, original);
                        }
                    }
                }
            }
        }
    }

    private void POSTScopeScan(PostRequest post) throws Exception {
        if (post.elements() > 0 && this.isRunning()) {
            this.callback.onPostObject(post);

            int vi, pi, ai, mi;
            /* loop each vulnerability */
            for (vi = 0; vi < this.vulnerabilities.size() && this.isRunning(); vi++) {
                Vulnerability vuln = this.vulnerabilities.elementAt(vi);
                /* loop each payload */
                for (pi = 0; pi < vuln.payloads.size() && this.isRunning(); pi++) {
                    Payload payload = vuln.payloads.elementAt(pi);
                    /* is a GET payload ? */
                    if ((payload.scopes.contains("POST") || payload.scopes.contains("post")) && this.isRunning()) {
                        /* loop each request argument */
                        for (ai = 0; ai < post.elements() && this.isRunning(); ai++) {
                            String original = post.getValue(ai);
                            String random = null;
                            if (payload.data.contains("@RANDOM")) {
                                random = StringManager.getRandomString(25);
                                payload.data = payload.data.replaceAll("@RANDOM", random);
                            }
                            post.setValue(ai, payload.data);
                            try {
                                String response = post.execute();
                                /* loop each matcher */
                                for (mi = 0; mi < vuln.matches.size(); mi++) {
                                    Match match = vuln.matches.elementAt(mi);
                                    if (match.data.contains("@PAYLOAD")) {
                                        match.data = match.data.replaceAll("@PAYLOAD", payload.data);
                                    }
                                    if (match.data.contains("@RANDOM") && random != null) {
                                        match.data = match.data.replaceAll("@RANDOM", random);
                                    }

                                    /* finally, we've got a match ? */
                                    if (match.match(response) == true) {
                                        this.callback.onPostMatch(post.copy(), response, vuln, pi, mi);
                                        post.setValue(ai, original);
                                        return;
                                    }
                                }
                            } catch (Exception e) {
                                this.callback.onConnectionError(post.action(), e.getMessage());
                            }


                            post.setValue(ai, original);
                        }
                    }
                }
            }
        }
    }
}
