/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.scanner.db;

import java.io.File;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.*;

public class Database {
    public Vector<Vulnerability> vulnerabilities;
    
    public Database( String basedir ) throws Exception {
        this.vulnerabilities = new Vector<Vulnerability>();
        File     dir   = new File(basedir);
        String[] files = dir.list();
        
        for( String file : files ){
            if( file.endsWith(".xml") ){
                this.loadFile(basedir + File.separatorChar + file);
            }
        }
    }
    
    private void loadFile( String filename ) throws Exception {
        DocumentBuilderFactory docfactory = DocumentBuilderFactory.newInstance();
        docfactory.setCoalescing(true);
        DocumentBuilder        docbuilder = docfactory.newDocumentBuilder();
        Document               document   = docbuilder.parse(new File(filename));

        int i, j;
        
        document.getDocumentElement().normalize();
        
        NodeList items = document.getElementsByTagName("item");
        
        for( i = 0; i < items.getLength(); i++ ){
            Element       root = (Element)items.item(i);
            Vulnerability vulnerability = new Vulnerability();
            
            vulnerability.name        = (root.getAttribute("name") == null ? "" : root.getAttribute("name").replace("\n", ""));
            vulnerability.severity    = (root.getAttribute("severity") == null ? "" : root.getAttribute("severity").replace("\n", ""));
            vulnerability.description = "";
            if( root.getElementsByTagName("description") != null ){
                if( root.getElementsByTagName("description").item(0) != null ){
                    vulnerability.description = ((Element)root.getElementsByTagName("description").item(0)).getChildNodes().item(0).getNodeValue();
                }
            }
            
            NodeList payloads  = root.getElementsByTagName("payload");
            for( j = 0; j < payloads.getLength(); j++ ){
                Element payxml  = (Element)payloads.item(j);
                Payload payload = new Payload();
                
                String  tmp     = payxml.getAttribute("scope").replace("\n", "");
                String[] scopes = tmp.split(",");
                for( String scope : scopes ){
                    payload.scopes.add(scope);
                }
                
                payload.data = payxml.getChildNodes().item(0).getNodeValue().replace("\n", "");
                
                vulnerability.payloads.add(payload);
            }
            
            NodeList matches  = root.getElementsByTagName("match");
            for( j = 0; j < matches.getLength(); j++ ){
                Element mxml  = (Element)matches.item(j);
                Match   match = new Match();
                
                String stype =  mxml.getAttribute("type").replace("\n", "");
                match.type = (stype.equalsIgnoreCase("regex") ? Match.REGEX : Match.SIMPLE);
                match.id   = mxml.getAttribute("id").replace("\n", "");
                match.data = mxml.getChildNodes().item(0).getNodeValue().replace("\n", "");
                
                vulnerability.matches.add(match);
            }
            
            this.vulnerabilities.add(vulnerability);
        }
    }
}
