/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.scanner;

import iscan.gui.MasterFrame;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.scanner.db.Vulnerability;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ScannerCallback {
    private MasterFrame masterframe;
    
    private String now() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(cal.getTime());

    }
    
    public ScannerCallback( MasterFrame mframe ){
        this.masterframe = mframe;
    }
    
    public void onDatabaseLoaded( int vulnerabilities, int payloads ){
        this.masterframe.AddMsg( now(), "Loaded " + payloads + " attack payloads from database .", vulnerabilities + " attack categories");
    }
    
    public void onGetObject( GetRequest get ){
        this.masterframe.AddMsg( now(), "Scanning '" + get.url() + "' (GET) ...", get.elements() + " arguments");
    }
    
    public void onPostObject( PostRequest post ){
        this.masterframe.AddMsg( now(), "Scanning '" + post.action() + "' (POST) ...", post.elements() + " arguments");
    }
    
    public void onGetMatch( GetRequest get, String response, Vulnerability v, int payload, int match ){
        /* ignore relative urls and path traversal */
        if( get.longurl().contains("..") == false ){
            this.masterframe.AddNode(get);
        }
        this.masterframe.alerttree.addGetAlert( get, response, v, payload, match );
    }
    
    public void onHeadermatch( GetRequest host, String header, Vulnerability v, int payload, int match ){
        this.masterframe.alerttree.addHeaderAlert( header, v, payload, match );
    }
    
    public void onPostMatch( PostRequest post, String response, Vulnerability v, int payload, int match ){
        this.masterframe.alerttree.addPostAlert( post, response, v, payload, match );
    }
    
    public void onConnectionError( String url, String message ){
        this.masterframe.AddMsg( now(), "!!? Warning : " + message, "" );
    }
    
    public void onScannerStop(){
        this.masterframe.AddMsg( now(), "!!? Scanner stopped .", "" );
    }
}
