/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.html;

import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.utils.StringManager;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.HTML.Tag;

public class HtmlParserCallback extends ParserCallback {
    private boolean    open_form_tag = false;
    private String     base_url;
    private String     page;
    private String     path;
    private Vector     http_objects;
    private PostRequest post_object = null;
    
    public HtmlParserCallback(String baseurl){
        baseurl = StringManager.getAfter( baseurl, "://" );
        
        this.path         = baseurl.substring(baseurl.indexOf("/"),baseurl.lastIndexOf("/") + 1);
        this.page         = baseurl.substring(baseurl.indexOf("/") + 1);
        this.base_url     = baseurl.substring(0,baseurl.indexOf("/"));
        this.http_objects = new Vector();
    }
    
    public Vector httpObjects(){
        return this.http_objects;
    }
    
    public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos) {
        if( t.equals(Tag.A) ){
            Object value = a.getAttribute(HTML.Attribute.HREF);
            if( value != null ){
                if( ((String)value).startsWith("/") == false && 
                    ((String)value).startsWith(".") == false &&
                    ((String)value).contains("://") == false ){
                    value = this.path + value;
                }
            }
            try{
                this.http_objects.add( new GetRequest( this.base_url, (value == null ? "" : value.toString()) ) );
            }
            catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog( null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE );
            }
        }
        else if( t.equals(Tag.FORM) ){
            Object action = a.getAttribute(HTML.Attribute.ACTION);
            this.open_form_tag = true;
            try{
               this.post_object   = new PostRequest( this.base_url, (action == null ? this.page : action.toString()) );
            }
            catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog( null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE );
            }
        }
        else if( t.equals(Tag.SELECT) && this.open_form_tag == true ){
            Object name  = a.getAttribute(HTML.Attribute.NAME);
            Object value = a.getAttribute(HTML.Attribute.VALUE);
            if( name != null ){
                this.post_object.addArgument( name.toString(), (value == null ? "" : value.toString()) );
            }
        }
        else{
            Object value = a.getAttribute(HTML.Attribute.SRC);
            if( value != null ){
                if( ((String)value).startsWith("/") == false && 
                    ((String)value).startsWith(".") == false &&
                    ((String)value).contains("://") == false ){
                    value = this.path + value;
                }
                
                try{
                    this.http_objects.add( new GetRequest( this.base_url, (value == null ? "" : value.toString()) ) );
                }
                catch(Exception e){
                    e.printStackTrace();
                    JOptionPane.showMessageDialog( null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE );
                }
            }
        }
    }

    public void handleEndTag(HTML.Tag t, int pos) {
        if( t.equals(Tag.FORM) && this.open_form_tag == true ){
            this.open_form_tag = false;
            this.http_objects.add( this.post_object );
            this.post_object = null;
        }
    }

    public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos) {
        if( t.equals(Tag.INPUT) && this.open_form_tag == true ){
            Object name  = a.getAttribute(HTML.Attribute.NAME);
            Object value = a.getAttribute(HTML.Attribute.VALUE);
            if( name != null ){
                this.post_object.addArgument( name.toString(), (value == null ? "" : value.toString()) );
            }
        }
        else if( t.equals(Tag.FRAME) ){
            Object value = a.getAttribute(HTML.Attribute.SRC);
            if( value != null ){
                if( ((String)value).startsWith("/") == false && 
                    ((String)value).startsWith(".") == false &&
                    ((String)value).contains("://") == false ){
                    value = this.path + value;
                }
            }
            try{
                this.http_objects.add( new GetRequest( this.base_url, (value == null ? "" : value.toString()) ) );
            }
            catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog( null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE );
            }
        }
        else{
            Object value = a.getAttribute(HTML.Attribute.SRC);
            if( value != null ){
                if( ((String)value).startsWith("/") == false && 
                    ((String)value).startsWith(".") == false &&
                    ((String)value).contains("://") == false ){
                    value = this.path + value;
                }
                
                try{
                    this.http_objects.add( new GetRequest( this.base_url, (value == null ? "" : value.toString()) ) );
                }
                catch(Exception e){
                    e.printStackTrace();
                    JOptionPane.showMessageDialog( null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE );
                }
            }
        }
    }
    
    /*
    public void handleError(String errorMsg, int pos){
    }
    
    public void handleText(char[] data, int pos){
    }

    public void handleComment(char[] data, int pos) {
    }
    */
    
}
