/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http.crawler;

import iscan.gui.MasterFrame;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

public class SmartCrawlerCallback {
    private MasterFrame masterframe;
    public  SmartCrawler crawler;
    public int gets;
    public int posts;
    public int deadlinks;
    
    public SmartCrawlerCallback( MasterFrame mframe ){
        this.masterframe = mframe;
        this.deadlinks   = 0;
    }
    
    public void onCrawlerStart( GetRequest root, Vector allowedextensions ){
        this.masterframe.AddMsg( now(), "Smart crawler started on " + root.longurl() + " .", "" );
        this.masterframe.AddInfo("Crawl Mode", (this.crawler.style() == SmartCrawler.FAST_CRAWL ? "Fast" : "Full") );
        this.masterframe.AddNode(root);
    }
    
    public void onCrawlerStop( Vector httpobjects ){
        this.masterframe.AddMsg( now(), "Smart crawler stopped, collected " + httpobjects.size() + " HTTP objects .", "" );
        this.masterframe.AddInfo("HTTP Objects", String.valueOf(httpobjects.size()) );
        
        
        int    nobjects    = httpobjects.size();
        this.gets  = 0;
        this.posts = 0;
        
        for( int i = 0; i < nobjects; i++ ){
            Object hobj = httpobjects.elementAt(i);

            if( hobj instanceof GetRequest ){
                this.gets++;
            }
            else if( hobj instanceof PostRequest ){
                this.posts++;
            }
        }
        
        this.masterframe.AddInfo("\tGET(s)", String.valueOf(this.gets) );
        this.masterframe.AddInfo("\tPOST(s)", String.valueOf(this.posts) );
        
        this.masterframe.AddInfo("Dead Links", String.valueOf(this.deadlinks) );
    }

    public String now() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(cal.getTime());

    }
    
    public void onUrlCrawl( GetRequest url, Vector urlobjects ){
        this.masterframe.AddMsg( now(), "Crawling '" + url.longurl() + "' ...", urlobjects.size() + " HTTP objects" );
        this.masterframe.AddNode(url);
    }
    
    public void onDeadUrl( GetRequest url, String details ){
         this.masterframe.AddMsg( now(), "!!! Error requesting '" + url.longurl() + "' !", details );
         this.deadlinks++;
    }
    
    public void onFile( GetRequest file ){
        this.masterframe.AddMsg( now(), "Skipping '" + file.longurl() + "' ...", "" );
        this.masterframe.AddNode(file);
    }
    
    public void onUnknownSource( GetRequest url ){
        this.masterframe.AddMsg( now(), "!!! Error requesting '" + url.longurl() + "' !", "UNKNOWN SOURCE" );
    }
    
    public void onCrawlDelay( int delay ){
        this.masterframe.AddMsg( now(), "Crawl delay ...", delay + " ms" );
    }
    
    public void onDepthLimitExceed( GetRequest url ){
        this.masterframe.AddMsg( now(), "!!? Skipping '" + url.longurl() + "' .", "Directory Depth Limit Exceed" );
    }
    
    public void onCachedUrl( GetRequest url ){
        
    }
    
    public void onExternalDomain( GetRequest url ){
        
    }
    
    public void onDisallowedExtension( GetRequest url ){
        
    }
}

