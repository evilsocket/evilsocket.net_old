/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http.crawler;

import iscan.Configuration;
import iscan.http.HttpManager;
import iscan.http.requests.GetRequest;
import iscan.http.requests.PostRequest;
import iscan.utils.StringManager;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.rmi.activation.UnknownObjectException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

public class SmartCrawler {
    public static final int FULL_CRAWL = 0;
    public static final int FAST_CRAWL = 2;
    
    private int    crawl_style;
    private Vector http_objects;
    private Vector extensions;
    private String root;
    private SmartCrawlerCallback callback;
    private boolean stop;
    
    private long starttime;
    private long stoptime;
    
    private Configuration configuration;
    
    public int style(){
        return this.crawl_style;
    }
    
    private synchronized boolean isCached( Object hobj ){
        for( int i = 0; i < this.http_objects.size(); i++ ){
            if( this.http_objects.elementAt(i) instanceof GetRequest && hobj instanceof GetRequest ){
                if( this.crawl_style == FAST_CRAWL ){
                    if( ((GetRequest)this.http_objects.elementAt(i)).fastequals((GetRequest)hobj) ){
                        return true;
                    }
                }
                else{
                    if( ((GetRequest)this.http_objects.elementAt(i)).fullequals((GetRequest)hobj) ){
                        return true;
                    }
                }
            }
            else if( this.http_objects.elementAt(i) instanceof PostRequest && hobj instanceof PostRequest ){
                if( ((PostRequest)this.http_objects.elementAt(i)).equals((PostRequest)hobj) ){
                    return true;
                }
            }
        }
        return false;
    }
    
    private synchronized boolean isAllowedExtension( GetRequest get ){
        String page = get.url().substring( get.url().lastIndexOf("/") + 1);
        String ext  = page.substring( page.indexOf(".") + 1 );
        if( ext.contains("#") ){
            ext = ext.substring(0,ext.indexOf("#"));
        }
        return this.configuration.allowedext.contains(ext) || ext.isEmpty();
    }
    
    private synchronized boolean isSameDomain( GetRequest get ) throws Exception {
        URL rooturl = new URL( this.root ),
            securl  = new URL( get.url() );
        
        return rooturl.getHost().equalsIgnoreCase(securl.getHost());
    }
    
    private synchronized boolean isAllowedDepth( GetRequest get ) throws Exception {
        return ( get.dirs().size() <= Configuration.getInstance().maxdirdepth );
    }
    
    private synchronized  int cacheObjects( Vector objects ){
        int i, count = 0;
        for( i = 0; i < objects.size(); i++ ){
            if( this.isCached(objects.elementAt(i)) == false ){
                this.http_objects.add(objects.elementAt(i));
                count++;
            }
        }
        return count;
    }
    
    private synchronized void cacheObject( Object object ){
        if( this.isCached(object) == false ){
            this.http_objects.add(object);
        }
    }
    
    private synchronized Vector getNonCachedObjects( Vector objects ){
        Vector noncached = new Vector();
        int i;
        for( i = 0; i < objects.size(); i++ ){
            if( this.isCached(objects.elementAt(i)) == false ){
                noncached.add(objects.elementAt(i));
            }
        }
        return noncached;
    }
    
    public SmartCrawler( String root, SmartCrawlerCallback callback, int style ){
        this.root             = root;
        this.http_objects     = new Vector();
        this.callback         = callback;
        this.callback.crawler = this;
        this.stop             = false;
        this.crawl_style      = style;
        this.configuration    = Configuration.getInstance();
    }
    
    public synchronized Vector getObjects(){
        return this.http_objects;
    }
    
    public void start() throws Exception {
        this.stop      = false;
        
        String tmp = StringManager.getAfter( this.root, "://" );
        
        String url = "", href = "";
        if( tmp.contains("/") ){
            url  = tmp.substring(0,tmp.indexOf("/") + 1);
            href = tmp.substring(tmp.indexOf("/"));
        }
        else{
            url  = this.root;
            href = "/";
        }
        
        GetRequest root = new GetRequest(url,href);

        this.callback.onCrawlerStart( root, this.extensions );

        this.starttime = Calendar.getInstance().getTimeInMillis();
        this.crawl(root);

        this.callback.onCrawlerStop( this.http_objects );
    }
    
    public void stop(){
        this.stop = true;
        this.stoptime = Calendar.getInstance().getTimeInMillis();
    }
    
    public String getCrawlTime(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss");
        return dateFormat.format(new Date(Calendar.getInstance().getTimeInMillis() - this.starttime));
    }
    
    private void doDelay() throws Exception{
        Random rand = new Random(); 
        int delta = rand.nextInt() % this.configuration.crawldelay,
            sleep = delta + this.configuration.crawldelay;
        this.callback.onCrawlDelay(sleep);
        Thread.sleep(sleep);
    }
    
    public synchronized void crawl( GetRequest get ) throws Exception {
        if( this.stop == false ){
            if( this.isCached(get) ){
                this.callback.onCachedUrl(get);
                return;
            }
            if( this.isAllowedExtension(get) == false ){
                if( this.crawl_style == FULL_CRAWL && this.isSameDomain(get) ){
                    this.cacheObject(get);
                    this.callback.onFile(get);
                }
                this.callback.onDisallowedExtension(get);
                return;
            }
            if( this.isAllowedDepth(get) == false ){
                this.callback.onDepthLimitExceed(get);
                return;
            }
            if( this.isSameDomain(get) == false ){
                this.callback.onExternalDomain(get);
                return;
            }
            
            if( this.configuration.crawdelayenabled == true && 
                this.configuration.crawldelay != 0 
                ){
                this.doDelay();
            }

            this.cacheObject(get);

            try
            {
                Vector pageobjects = HttpManager.getObjects(get.longurl());    
                pageobjects        = this.getNonCachedObjects(pageobjects);
                int    nobjects    = pageobjects.size();

                this.callback.onUrlCrawl( get, pageobjects );

                int i;
                for( i = 0; i < nobjects; i++ ){
                    if( pageobjects.elementAt(i) instanceof GetRequest ){
                        this.crawl( (GetRequest)pageobjects.elementAt(i) );
                    }
                    else{
                        this.cacheObject(pageobjects.elementAt(i));
                    }
                }
            }
            catch( FileNotFoundException fnf ){
                this.http_objects.remove( this.http_objects.size() - 1 );
                this.callback.onDeadUrl( get, "File Not Found" ); 
            }
            catch( IOException e ){
                this.http_objects.remove( this.http_objects.size() - 1 );
                this.callback.onDeadUrl( get, e.toString() ); 
            }
            catch( UnknownObjectException e ){
                
            }
        }
    }
}
