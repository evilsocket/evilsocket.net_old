/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http.requests;

import iscan.Constants;
import iscan.http.*;
import iscan.http.HttpManager;
import iscan.utils.StringManager;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Vector;

public class GetRequest {
    private String page;
    private String url;
    private String longurl;
    private Vector dirs;
    private Vector arguments;
    private Vector values;
    
    
    public GetRequest( String baseurl, String href ) throws Exception{
        if( href.contains("://") ){
            this.longurl = this.url = href;
        }
        else if( href.startsWith("#") ){
            this.longurl = this.url = (baseurl.contains("://") ? baseurl : Constants.default_schema + "://" + baseurl) + (baseurl.endsWith("/") ? "" : "/");
        }
        else{
            this.longurl = this.url = (baseurl.contains("://") ? baseurl : Constants.default_schema + "://" + baseurl) + (href.startsWith("/") || baseurl.endsWith("/") ? href : "/" + href );
        }
        
        this.longurl = StringManager.fixRelativeUrl(this.longurl);
        this.url     = StringManager.fixRelativeUrl(this.url);
        
        this.longurl = StringManager.getBefore( this.longurl, "#" );
        this.longurl = StringManager.getBefore( this.longurl.toLowerCase(), "javascript:" );
        this.longurl = StringManager.getBefore( this.longurl.toLowerCase(), "mailto:" );

        this.longurl = this.url = URLDecoder.decode( this.longurl, "UTF-8");
        
        this.arguments = new Vector();
        this.values    = new Vector();
        
        if( this.url.contains("?") ){
            String[] couples;
            if( this.url.contains("&") ){
                couples = StringManager.getAfter( this.url, "?" ).split("&");
            }
            else{
                couples = new String[1];
                couples[0] = StringManager.getAfter( this.url, "?" );
            }
            for( String couple : couples ){
                if( couple.contains("=") ){
                    String[] values = couple.split("=");
                    String arg = (values.length > 0 && values[0] != null ? values[0] : ""),
                           val = (values.length > 1 && values[1] != null ? values[1] : "");
                    
                    this.arguments.add(arg);
                    this.values.add(val);
                }
            }   
            this.url = StringManager.getBefore( this.url, "?" );
        }
        
        this.dirs = new Vector();
        this.dirs.add("/");
        
        String tmpurl = StringManager.getAfter( StringManager.getAfter( this.url, "://" ), "/" );
        
        String[] values = tmpurl.split("/");
        String   last   = this.dirs.elementAt(0).toString();
        this.page = "";
        for( String dir : values ){
            if( dir.equals("..") ){
                this.dirs.remove(last);
            }
            else if( dir.equals(".") || dir.equals("") ){
                
            }
            else{
                this.page += (dir.equals("/") ? "" : "/") + dir;
                this.dirs.add(dir);
                last = dir;
            } 
        }
    }
    
    public String host(){
        return StringManager.getBetween( this.url, "://", "/" );
    }
    
    public GetRequest copy() throws Exception {
        return new GetRequest( "", this.longurl );
    }
    
    public String page(){
        return this.page;
    }
    
    public String url(){
        return this.url;
    }
    
    public String longurl(){
        return this.longurl;
    }
    
    public Vector dirs(){
        return this.dirs;
    }
    
    public int elements(){
        return this.arguments.size();
    }
    
    public Vector arguments(){
        return this.arguments;
    }
    
    public Vector values(){
        return this.values;
    }
    
    public String getArgument( int index ){
        return (String)this.arguments.elementAt(index);
    }
    
    public String getValue( int index ){
        return (String)this.values.elementAt(index);
    }
    
    public void setArgument( int index, String name ){
       this.arguments.setElementAt( name, index );
    }
    
    public void setValue( int index, String value ) throws Exception {
        this.values.setElementAt( URLEncoder.encode( value, "UTF-8"), index );
        this.longurl = this.url + "?";
        /* rebuild long url */
        for( int i = 0; i < this.values.size(); i++ ){
            this.longurl += this.arguments.elementAt(i) + "=" + this.values.elementAt(i) + "&";
        }
    }
    
    public boolean fastequals( GetRequest get  ){
        if( get.url().equals(this.url) == false ){
            return false;
        }
        
        Vector argv = get.arguments();
        int    argc = argv.size(), i;
        for( i = 0; i < argc; i++ ){
            if( this.arguments().contains(argv.elementAt(i)) == false ){
                return false;
            }
        }
        
        return true;
    }
    
    public boolean fullequals( GetRequest get  ){
       return get.longurl().equals(this.longurl());
    }
    
    public String execute() throws Exception {
        return HttpManager.getContent( this.longurl() );
    }
}
