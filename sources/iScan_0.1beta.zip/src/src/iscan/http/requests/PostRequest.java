/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http.requests;

import iscan.Constants;
import iscan.http.*;
import iscan.http.HttpManager;
import iscan.utils.StringManager;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Vector;

public class PostRequest {
    private String action;
    private Vector dirs;
    private Vector arguments;
    private Vector values;
    
    public PostRequest( String baseurl, String action ) throws Exception {
        if( action.contains("://") ){
            this.action = action;
        }
        else{
            this.action = (baseurl.contains("://") ? baseurl : Constants.default_schema + "://" + baseurl) + (action.startsWith("/") || baseurl.endsWith("/") ? action : "/" + action);
        }
        
        if( this.action.contains("#") ){
            this.action = this.action.substring(0, this.action.indexOf("#"));
        }
        
        this.action = StringManager.fixRelativeUrl(this.action);
        
        this.action = URLDecoder.decode( this.action, "UTF-8");
        
        this.arguments = new Vector();
        this.values    = new Vector();
        
        this.dirs = new Vector();
        this.dirs.add("/");
        
        String tmpurl = StringManager.getAfter( StringManager.getAfter( this.action, "://" ), "/" );
        
        String[] values = tmpurl.split("/");
        String   last   = this.dirs.elementAt(0).toString();
        for( String dir : values ){
            if( dir.equals("..") ){
                this.dirs.remove(last);
            }
            else if( dir.equals(".") || dir.equals("") ){
                
            }
            else{
                this.dirs.add(dir);
                last = dir;
            } 
        }
    }
    
    public String host(){
        return StringManager.getBetween( this.action, "://", "/" );
    }
    
    public String page(){
        return "/" + StringManager.getBetween( StringManager.getAfter( this.action, "://" ), "/", "?" );
    }
    
    public PostRequest copy() throws Exception {
        PostRequest copy = new PostRequest( "", this.action );
        int    argc = this.arguments.size(), i;
        for( i = 0; i < argc; i++ ){
            copy.addArgument( (String)this.arguments.elementAt(i), (String)this.values.elementAt(i) );
        }
        return copy;
    }
    
    public void addArgument( String name, String value ){
        this.arguments.add(name);
        this.values.add(value);
    }
    
    public String action(){
        return this.action;
    }
    
    public Vector dirs(){
        return this.dirs;
    }
    
    public int elements(){
        return this.arguments.size();
    }
    
    public Vector arguments(){
        return this.arguments;
    }
    
    public Vector values(){
        return this.values;
    }
    
    public String longurl(){
        String base = this.action + "?";
        int    argc = this.arguments.size(), i;
        for( i = 0; i < argc; i++ ){
            base += this.arguments.elementAt(i) + "=" + this.values.elementAt(i) + "&";
        }
        return base;
    }
    
    public String getArgument( int index ){
        return (String)this.arguments.elementAt(index);
    }
    
    public String getValue( int index ){
        return (String)this.values.elementAt(index);
    }
    
    public void setArgument( int index, String name ){
       this.arguments.setElementAt( name, index );
    }
    
    public void setValue( int index, String value ) throws Exception {
        this.values.setElementAt( URLEncoder.encode( value, "UTF-8"), index );
    }
    
    public boolean equals( PostRequest post  ){
        if( this.action.equalsIgnoreCase(post.action()) == false ){
            return false;
        }
        
        if( this.elements() != post.elements() ){
            return false;
        }
        
        Vector argv = post.arguments();
        int    argc = argv.size(), i;
        for( i = 0; i < argc; i++ ){
            if( this.arguments().contains(argv.elementAt(i)) == false ){
                return false;
            }
        }
                
        return true;
    }
    
    public String execute() throws Exception {
        return HttpManager.postContent( this.action, this.arguments, this.values );
    }
}
