/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http;

import iscan.Configuration;
import iscan.utils.StringManager;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

public class HttpInfo {
    private static volatile HttpInfo INSTANCE = null;
    
    public String hostname  = "";
    public String ipaddress = "";
    public String server    = "";
    public String methods   = "";
    
    public HttpInfo( String url ) throws Exception {
        url = StringManager.getBetween( url, "://", "/" );
        
        InetAddress address = InetAddress.getByName(url);
        
        this.hostname = url;
        this.ipaddress = address.getHostAddress();
        
        Socket socket = new Socket( address, 80 );
        
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    
        writer.write("DELETE / HTTP/1.1\r\n");
        Configuration config  = Configuration.getInstance();
        if( config.useragent != "" ){
            writer.write("User-Agent: " + config.useragent + "\r\n" );
        }
        if( config.referer != "" ){
            writer.write("Referer: " + config.referer + "\r\n" );
        }
        writer.write("\r\n");
        writer.flush();
        
        String line;
        while ((line = reader.readLine()) != null) {
            if( line.startsWith("Server:") ){
                this.server = line.substring("Server: ".length());
            }
            else if( line.startsWith("Allow:") ){
                 this.methods = line.substring("Allow: ".length());
            }
        }
        
        writer.close();
        reader.close();
        socket.close();
        
        HttpInfo.INSTANCE = this;
    }
    
    public static HttpInfo getInstance(){
        return HttpInfo.INSTANCE;
    }
}
