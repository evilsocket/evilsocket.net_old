/*
 *  iScan Web Vulnerability Scanner
 *  
 *  Copyright 2008 evilsocket <evilsocket@gmail.com>
 * 
 * 		http://www.evilsocket.net
 * 		  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA 02110-1301, USA.
 */

package iscan.http;

import iscan.Configuration;
import iscan.Constants;
import iscan.html.HtmlParser;
import iscan.html.HtmlParserCallback;
import iscan.http.requests.GetRequest;
import iscan.utils.StringManager;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Vector;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class HttpManager {
    public static Reader getReader( String resource ) throws Exception{
        Configuration config     = Configuration.getInstance();
        URL           url;   
        if( config.proxyenabled ){
            url = new URL( Constants.default_schema, config.proxyserver, config.proxyport, resource );
        }
        else{
            url = new URL(resource);
        }
        
        URLConnection connection = url.openConnection();
        if( config.useragent.isEmpty() == false  ){
            connection.setRequestProperty("User-Agent", config.useragent );
        }
        if( config.referer.isEmpty() == false  ){
            connection.setRequestProperty("Referer", config.referer );
        }
        else{
            connection.setRequestProperty( "Referer", url.toExternalForm() );
        }
        
        connection.setRequestProperty( "Host", url.getHost() );
        connection.setRequestProperty( "Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" );
        connection.setRequestProperty( "Keep-Alive", "300" );
        connection.setRequestProperty( "Connection", "keep-alive" );        
        connection.setRequestProperty( "Cache-Control", "max-age=0" );

        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setUseCaches(false);
                
        HttpURLConnection http = (HttpURLConnection)connection;
        if( http.getResponseCode() != 500 ){
            return new BufferedReader(new InputStreamReader(http.getInputStream()));
        } else {
            return new BufferedReader(new InputStreamReader(http.getErrorStream()));
        }
    }
    
    public static Vector getObjects( String resource ) throws Exception{
        HtmlParserCallback callback = new HtmlParserCallback(resource);
        HtmlParser.parse( resource, (ParserCallback)callback );

        return callback.httpObjects();
    }
    
    public static String getHttpHeader( String host ) throws Exception{
        String header         = "",
               request        = "";
        Socket socket         = new Socket( InetAddress.getByName(host), 80 );
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        Configuration config  = Configuration.getInstance();
        
        request = "HEAD / HTTP/1.1\r\n";
        if( config.useragent.isEmpty() == false ){
            request += "User-Agent: " + config.useragent + "\r\n";
        }
        if( config.referer.isEmpty() ){
            request += "Referer: " + config.referer + "\r\n";
        }
        else{
            request += "Referer: " + host + "\r\n";
        }
        request += "Host: " + host + "\r\n";
        request += "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5\r\n";
        request += "Keep-Alive: 300\r\n";
        request += "Connection: keep-alive\r\n";        
        request += "Cache-Control: max-age=0\r\n";
        request += "\r\n";
        
        writer.write(request);
        writer.flush();
        
        String line;
        while ((line = reader.readLine()) != null) {
            header += line + "\n";
        }
        
        writer.close();
        reader.close();
        socket.close();
        
        return header;
    }
    
    public static String get404Payload(String host) {
        String payload = null;
        try {
            String random = StringManager.getRandomString(25) + ".html";
            GetRequest nonexistent = new GetRequest(host, random);
            String response = nonexistent.execute();

            if (response.contains(random) == false) {
                payload = response;
            } else {
                payload = StringManager.getBefore(response, random);
            }
        } catch (Exception e) {
            return null;
        }

        return payload;
    }
    
    public static String getContent( String resource ) throws Exception{
        BufferedReader reader = (BufferedReader)getReader(resource);
        String content = new String(),
               line;
        
        while( (line = reader.readLine()) != null ){
            content += line + "\n";
        }
        
        reader.close();
        return content;
    }
    
    public static String postContent( String resource, Vector args, Vector values ) throws Exception{
        String post = new String();
        
        for( int i = 0; i < args.size(); i++ ){
            post += URLEncoder.encode( args.elementAt(i).toString(), "UTF-8")   + "=" +  
                    URLEncoder.encode( values.elementAt(i).toString(), "UTF-8") + "&";
        }
        
        URL           url        = new URL(resource);
        URLConnection connection = url.openConnection();
        Configuration config     = Configuration.getInstance();
        if( config.useragent.isEmpty() == false ){
            connection.setRequestProperty("User-Agent", config.useragent );
        }
        if( config.referer.isEmpty() == false ){
            connection.setRequestProperty("Referer", config.referer );
        }
        
        connection.setRequestProperty( "Host", url.getHost() );
        connection.setRequestProperty( "Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5" );
        connection.setRequestProperty( "Cache-Control", "max-age=0" );
        connection.setRequestProperty( "Keep-Alive", "300" );
        connection.setRequestProperty( "Connection", "keep-alive" );
        connection.setRequestProperty( "Referer", url.toExternalForm() );
        connection.setRequestProperty( "Content-Length", String.valueOf(post.length()) );
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setUseCaches(false);
        
        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
        writer.write(post);
        writer.flush();
    
        BufferedReader reader = null;
        HttpURLConnection http = (HttpURLConnection)connection;
        if( http.getResponseCode() != 500 ){
            reader = new BufferedReader(new InputStreamReader(http.getInputStream()));
        } else {
            reader = new BufferedReader(new InputStreamReader(http.getErrorStream()));
        }
        
        String content = new String(),
               line;
        
        while( (line = reader.readLine()) != null ){
            content += line + "\n";
        }
        
        writer.close();
        reader.close();
        
        return content;
    }
}
