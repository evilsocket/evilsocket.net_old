#import "ViewController2.h"

@implementation ViewController2

@synthesize navbar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        /*
		 * Creo la navigation bar, con il tasto 'Indietro' essendo questa la seconda vista.
		 */
		self.navbar = AddNavigationBar( self, @"Vista 2", YES );
    }
    return self;
}

- (void)navigationBar:(UINavigationBar*)bar buttonClicked:(int)button
{
	/*
	 * Il tasto 'Indietro' è stato premuto, torniamo alla prima view ^^
	 */
	BackFromView(self);
}

- (void)viewDidUnload {
    [super viewDidUnload];
    [navbar release];
}

@end
