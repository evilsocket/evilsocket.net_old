#import <Foundation/Foundation.h>

/*
 * Aggiunge una UINavigationBar alla view 'root' con il titolo 'title', 
 * se 'withBack' è YES aggiunge il tasto 'Indietro'.
 */
UINavigationBar *AddNavigationBar( UIViewController *root, NSString *title, BOOL withBack ); 
/*
 * Esegue una transazione animata dalla view 'from' alla view 'to' .
 */
void GoToView( UIViewController *from, UIViewController *to );
/*
 * Esegue una transazione animata tornando alla view precedente.
 */
void BackFromView( UIViewController *from );


