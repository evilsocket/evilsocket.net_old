#import <UIKit/UIKit.h>
#import "Utilities.h"

/*
 * Eseguo qui una pseudo dichiarazione del secondo controller invece
 * di includere il rispettivo header per non creare inclusioni cicliche.
 */
@class ViewController2;

@interface ViewController1 : UIViewController {
	UINavigationBar *navbar;
	ViewController2 *seconda;
}

@property (nonatomic, retain) UINavigationBar *navbar;
@property (nonatomic, retain) ViewController2 *seconda;

- (IBAction)secondaVista;

@end

