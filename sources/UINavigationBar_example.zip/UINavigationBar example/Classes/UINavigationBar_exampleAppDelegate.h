//
//  UINavigationBar_exampleAppDelegate.h
//  UINavigationBar example
//
//  Created by Simone Margaritelli on 05/11/10.
//  Copyright 2010 None. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController1;

@interface UINavigationBar_exampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ViewController1 *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ViewController1 *viewController;

@end

