#import <UIKit/UIKit.h>
#import "Utilities.h"

@interface ViewController2 : UIViewController {
	UINavigationBar *navbar;
}

@property (nonatomic, retain) UINavigationBar *navbar;

@end
