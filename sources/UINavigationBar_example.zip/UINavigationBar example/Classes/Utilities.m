#import "Utilities.h"

UINavigationBar *AddNavigationBar( UIViewController *root, NSString *title, BOOL withBack ){
	UINavigationBar *navbar;
	CGRect			 top;
	/*
	 * Creo la barra nel rettangolo superiore dello schermo.
	 */
	top    = CGRectMake(0.0f, 0.0f, 320.0f, 44.0f);
	navbar = [[UINavigationBar alloc] initWithFrame:top];
	/*
	 * Imposto lo stile della barra come nero opaco.
	 */
	navbar.barStyle		  = UIBarStyleBlackOpaque;
	/*
	 * Aggiungo il titolo.
	 */
	[navbar pushNavigationItem: [[UINavigationItem alloc ] initWithTitle:title]];
	/*
	 * Se il flag withBack è stato impostato, aggiungo il tasto 'Indietro'.
	 */
	if( withBack ){
		navbar.backItem.title = @"Indietro";
		[navbar showLeftButton: @"Indietro" withStyle:1 rightButton:nil withStyle: 0 ];
	}
	/*
	 * Imposto il delegate.
	 */
	[navbar setDelegate:root];
	/*
	 * Aggiungo la barra come subview.
	 */
	[root.view addSubview:navbar];
	
	return navbar;
}

void GoToView( UIViewController *from, UIViewController *to ){	
	/*
	 * Preparo l'animazione e aggiungo la subview.
	 */
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:from.view cache:YES];
		[from.view addSubview:to.view];
	[UIView commitAnimations];
}

void BackFromView( UIViewController *from ){
	/*
	 * Preparo l'animazione e rimuovo la view attuale dalla superview.
	 */
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationTransition: UIViewAnimationTransitionCurlDown forView:from.view.superview cache:YES];
		[from.view removeFromSuperview];
	[UIView commitAnimations];	
}
