#import "ViewController1.h"
#import "ViewController2.h"

@implementation ViewController1

@synthesize navbar, seconda;

- (void)viewDidLoad {
	[super viewDidLoad];
	/*
	 * Creo la navigation bar, senza il tasto 'Indietro' essendo questa la prima vista.
	 */
	self.navbar = AddNavigationBar( self, @"Vista 1", NO );
	/*
	 * Alloco il controller per la seconda vista.
	 */
	self.seconda = [[ViewController2 alloc] initWithNibName:@"View2" bundle:nil];
}

- (IBAction)secondaVista {
	GoToView( self, self.seconda );
}

- (void)viewDidUnload {
	/*
	 * Sempre deallocare gli oggetti quando la vista viene unloadata! :)
	 */
	[navbar release];
	[seconda release];
}

@end
