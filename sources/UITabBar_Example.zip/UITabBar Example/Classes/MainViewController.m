/***************************************************************************
 *   UITabBar with more than 5 tabs example                                *
 *   by Simone Margaritelli - evilsocket@gmail.com                         *
 *   http://www.evilsocket.net                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#import "MainViewController.h"

@implementation MainViewController


@synthesize tabBar;
@synthesize currentView;
@synthesize viewControllers;

/*
 * Metodo per gestire il protocollo di UITabBarController nel momento in cui viene 
 * selezionato un tab.
 */
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {	
    [self selectTab:item.tag];
}

/*
 * Metodo per attivare la View in base al tab selezionato.
 */
- (void)selectTab:(int)tag {
	/*
	 * Prelevo dall'array il view controller che mi interessa.
	 */
	UIViewController *viewController = [viewControllers objectAtIndex:tag];
	/*
	 * Accertiamoci che non sia già selezionata la vista.
	 */
	if( viewController == currentView ){
		return;
	}
	/*
	 * Inserisco la view al di sotto della UITabBar.
	 */
	[self.view insertSubview: viewController.view belowSubview: tabBar];
	/*
	 * Se è già attiva una vista, la rimuovo.
	 */
	if( currentView != nil ){
		[currentView.view removeFromSuperview];
	}
	/*
	 * Imposto la vista attualmente attiva.
	 */
	currentView = viewController;
}

/*
 * Al caricamento della view principale, inizializzo le variabili ed 
 * imposto il primo tab come quello attivo.
 */
- (void)viewDidLoad {
    [super viewDidLoad];
	
	/*
	 * Creo l'array e lo imposto per contenere il numero di tab desiderato.
	 */
	viewControllers = [[NSMutableArray alloc] initWithCapacity:N_TABS];
	/*
	 * Per ogni tab, creo un UIViewController tramite i relativo NIB e lo 
	 * aggiungo nell'array.
	 */
	for( int i = 0; i < N_TABS; ++i ){
		[viewControllers addObject: [[UIViewController alloc] initWithNibName: [[NSString alloc] initWithFormat:@"tab%d", i] bundle:nil]];
	}

	[tabBar setSelectedItem:[tabBar.items objectAtIndex:0]];
    [self selectTab:0];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
	self.tabBar = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
